AETHER CITADEL - GitHub Pages static deployment package
Upload the CONTENTS of this folder to the repository root (main branch).
The app loads Three.js 0.170.0 and its examples from jsDelivr CDN; an internet connection is required.
Original scene/model/shader/assets are retained. Stability patch changes remain in src/main.js.

Build configuration: package.json added for the standard Vite build. Texture URL in src/main.js corrected to ./tex/ for GitHub Pages project-base resolution. Existing scene, model, shader, font, and texture files are retained.
