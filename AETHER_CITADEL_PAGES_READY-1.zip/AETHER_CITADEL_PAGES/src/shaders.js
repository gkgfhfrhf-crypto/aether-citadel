import * as THREE from 'three';

const V_HEAD = /* glsl */ `
#include <common>
#include <logdepthbuf_pars_vertex>
`;
const F_HEAD = /* glsl */ `
#include <common>
#include <logdepthbuf_pars_fragment>
`;

// Ashima 3D simplex noise
const NOISE = /* glsl */ `
vec3 mod289(vec3 x){return x-floor(x*(1.0/289.0))*289.0;}
vec4 mod289(vec4 x){return x-floor(x*(1.0/289.0))*289.0;}
vec4 permute(vec4 x){return mod289(((x*34.0)+1.0)*x);}
vec4 taylorInvSqrt(vec4 r){return 1.79284291400159-0.85373472095314*r;}
float snoise(vec3 v){
  const vec2 C=vec2(1.0/6.0,1.0/3.0); const vec4 D=vec4(0.0,0.5,1.0,2.0);
  vec3 i=floor(v+dot(v,C.yyy)); vec3 x0=v-i+dot(i,C.xxx);
  vec3 g=step(x0.yzx,x0.xyz); vec3 l=1.0-g; vec3 i1=min(g.xyz,l.zxy); vec3 i2=max(g.xyz,l.zxy);
  vec3 x1=x0-i1+C.xxx; vec3 x2=x0-i2+C.yyy; vec3 x3=x0-D.yyy;
  i=mod289(i);
  vec4 p=permute(permute(permute(i.z+vec4(0.0,i1.z,i2.z,1.0))+i.y+vec4(0.0,i1.y,i2.y,1.0))+i.x+vec4(0.0,i1.x,i2.x,1.0));
  float n_=0.142857142857; vec3 ns=n_*D.wyz-D.xzx;
  vec4 j=p-49.0*floor(p*ns.z*ns.z); vec4 x_=floor(j*ns.z); vec4 y_=floor(j-7.0*x_);
  vec4 x=x_*ns.x+ns.yyyy; vec4 y=y_*ns.x+ns.yyyy; vec4 h=1.0-abs(x)-abs(y);
  vec4 b0=vec4(x.xy,y.xy); vec4 b1=vec4(x.zw,y.zw);
  vec4 s0=floor(b0)*2.0+1.0; vec4 s1=floor(b1)*2.0+1.0; vec4 sh=-step(h,vec4(0.0));
  vec4 a0=b0.xzyw+s0.xzyw*sh.xxyy; vec4 a1=b1.xzyw+s1.xzyw*sh.zzww;
  vec3 p0=vec3(a0.xy,h.x); vec3 p1=vec3(a0.zw,h.y); vec3 p2=vec3(a1.xy,h.z); vec3 p3=vec3(a1.zw,h.w);
  vec4 norm=taylorInvSqrt(vec4(dot(p0,p0),dot(p1,p1),dot(p2,p2),dot(p3,p3)));
  p0*=norm.x; p1*=norm.y; p2*=norm.z; p3*=norm.w;
  vec4 m=max(0.6-vec4(dot(x0,x0),dot(x1,x1),dot(x2,x2),dot(x3,x3)),0.0); m=m*m;
  return 42.0*dot(m*m,vec4(dot(p0,x0),dot(p1,x1),dot(p2,x2),dot(p3,x3)));
}
`;

/* ------------------------------------------------------------------ */
/* Atmosphere: back-side Rayleigh halo + front-side limb haze          */
/* ------------------------------------------------------------------ */
export function makeAtmosphereMaterial({ color, twilight, intensity, power, k, front, sunDir }) {
  return new THREE.ShaderMaterial({
    uniforms: {
      uColor: { value: new THREE.Color(...color) },
      uTwilight: { value: new THREE.Color(...twilight) },
      uSunDir: { value: sunDir },
      uIntensity: { value: intensity },
      uPower: { value: power },
      uK: { value: k },
      uFront: { value: front ? 1 : 0 },
    },
    vertexShader: V_HEAD + /* glsl */ `
      varying vec3 vN; varying vec3 vP;
      void main(){
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vP = wp.xyz;
        vN = normalize(mat3(modelMatrix) * normal);
        gl_Position = projectionMatrix * viewMatrix * wp;
        #include <logdepthbuf_vertex>
      }`,
    fragmentShader: F_HEAD + /* glsl */ `
      uniform vec3 uColor; uniform vec3 uTwilight; uniform vec3 uSunDir;
      uniform float uIntensity; uniform float uPower; uniform float uK; uniform float uFront;
      varying vec3 vN; varying vec3 vP;
      void main(){
        #include <logdepthbuf_fragment>
        vec3 V = normalize(cameraPosition - vP);
        vec3 N = normalize(vN);
        float d = dot(N, V);
        float a = uFront > 0.5
          ? pow(1.0 - clamp(d, 0.0, 1.0), uPower * 2.4)
          : pow(clamp(-d / uK, 0.0, 1.0), uPower);
        float s = dot(N, normalize(uSunDir));
        float lit = smoothstep(-0.34, 0.34, s);
        vec3 col = mix(uTwilight, uColor, smoothstep(-0.06, 0.48, s));
        gl_FragColor = vec4(col * a * lit * uIntensity, 1.0);
      }`,
    side: front ? THREE.FrontSide : THREE.BackSide,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
}

/* ------------------------------------------------------------------ */
/* Saturn ring: radial texture, planet shadow, backlit scattering      */
/* ------------------------------------------------------------------ */
export function makeRingMaterial(tex, sunDir, radius) {
  return new THREE.ShaderMaterial({
    uniforms: {
      uTex: { value: tex },
      uSunDir: { value: sunDir },
      uR: { value: radius },
      uCenter: { value: new THREE.Vector3() },
    },
    vertexShader: V_HEAD + /* glsl */ `
      varying vec2 vUv; varying vec3 vP; varying vec3 vN;
      void main(){
        vUv = uv;
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vP = wp.xyz;
        vN = normalize(mat3(modelMatrix) * normal);
        gl_Position = projectionMatrix * viewMatrix * wp;
        #include <logdepthbuf_vertex>
      }`,
    fragmentShader: F_HEAD + /* glsl */ `
      uniform sampler2D uTex; uniform vec3 uSunDir; uniform float uR; uniform vec3 uCenter;
      varying vec2 vUv; varying vec3 vP; varying vec3 vN;
      void main(){
        #include <logdepthbuf_fragment>
        vec4 t = texture2D(uTex, vec2(vUv.x, 0.5));
        vec3 L = normalize(uSunDir);
        vec3 o = vP - uCenter;
        float b = dot(o, L);
        float h = b * b - (dot(o, o) - uR * uR);
        float sh = b < 0.0 ? smoothstep(0.0, uR * uR * 0.05, h) : 0.0;
        vec3 N = normalize(vN);
        vec3 V = normalize(cameraPosition - vP);
        float ndl = abs(dot(N, L));
        bool litSide = dot(N, L) * dot(N, V) > 0.0;
        float light = litSide ? (0.28 + 1.12 * ndl) : (0.2 + 0.45 * ndl) * (1.0 - t.a * 0.52);
        vec3 col = t.rgb * light * (1.0 - 0.94 * sh) * 1.48;
        gl_FragColor = vec4(col, t.a * 0.96);
      }`,
    side: THREE.DoubleSide,
    transparent: true,
    depthWrite: false,
  });
}

/* ------------------------------------------------------------------ */
/* Deep 3D volumetric starfield (real 3D stars around space)           */
/* ------------------------------------------------------------------ */
export function makeDeepStars(count = 7500) {
  const geo = new THREE.BufferGeometry();
  const pos = new Float32Array(count * 3);
  const col = new Float32Array(count * 3);
  const size = new Float32Array(count);

  const palette = [
    new THREE.Color(0.68, 0.82, 1.0),  // O/B blue-white
    new THREE.Color(0.95, 0.97, 1.0),  // A white
    new THREE.Color(1.0, 0.94, 0.82),  // F/G warm yellow-white
    new THREE.Color(1.0, 0.78, 0.58),  // K/M orange
  ];

  for (let i = 0; i < count; i++) {
    const r = 18000 + Math.pow(Math.random(), 0.55) * 420000;
    const u = Math.random() * 2 - 1;
    const th = Math.random() * Math.PI * 2;
    const s = Math.sqrt(1 - u * u);
    pos[i * 3] = r * s * Math.cos(th);
    pos[i * 3 + 1] = r * u;
    pos[i * 3 + 2] = r * s * Math.sin(th);

    const c = palette[Math.floor(Math.pow(Math.random(), 1.5) * palette.length)];
    const bright = 0.35 + Math.pow(Math.random(), 2.2) * 1.35;
    col[i * 3] = c.r * bright;
    col[i * 3 + 1] = c.g * bright;
    col[i * 3 + 2] = c.b * bright;
    size[i] = 0.8 + Math.pow(Math.random(), 2.8) * 2.6;
  }
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  geo.setAttribute('aColor', new THREE.BufferAttribute(col, 3));
  geo.setAttribute('aSize', new THREE.BufferAttribute(size, 1));

  const mat = new THREE.ShaderMaterial({
    uniforms: { uPR: { value: 1 }, uAlpha: { value: 1 }, uTime: { value: 0 } },
    vertexShader: V_HEAD + /* glsl */ `
      attribute vec3 aColor; attribute float aSize;
      uniform float uPR; uniform float uTime;
      varying vec3 vCol; varying float vTwinkle;
      void main(){
        vCol = aColor;
        vTwinkle = 0.86 + 0.14 * sin(uTime * 1.7 + position.x * 0.01 + position.y * 0.013);
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        gl_PointSize = aSize * uPR;
        gl_Position = projectionMatrix * mv;
        #include <logdepthbuf_vertex>
      }`,
    fragmentShader: F_HEAD + /* glsl */ `
      uniform float uAlpha;
      varying vec3 vCol; varying float vTwinkle;
      void main(){
        #include <logdepthbuf_fragment>
        float d = length(gl_PointCoord - 0.5);
        float a = smoothstep(0.5, 0.05, d) * uAlpha * vTwinkle;
        gl_FragColor = vec4(vCol * a, 1.0);
      }`,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const pts = new THREE.Points(geo, mat);
  pts.frustumCulled = false;
  return pts;
}

/* ------------------------------------------------------------------ */
/* Hyperspace star streaks (instanced quads attached to camera)        */
/* ------------------------------------------------------------------ */
export function makeStreaks(count, length) {
  const geo = new THREE.InstancedBufferGeometry();
  const corners = new Float32Array([-1, 0, 1, 0, -1, 1, 1, 1]);
  geo.setAttribute('position', new THREE.Float32BufferAttribute(new Float32Array(12), 3));
  geo.setAttribute('corner', new THREE.Float32BufferAttribute(corners, 2));
  geo.setIndex([0, 2, 1, 2, 3, 1]);

  const pos = new Float32Array(count * 3);
  const rnd = new Float32Array(count);
  for (let i = 0; i < count; i++) {
    const r = 3.2 + Math.pow(Math.random(), 0.62) * 180;
    const a = Math.random() * Math.PI * 2;
    pos[i * 3] = Math.cos(a) * r;
    pos[i * 3 + 1] = Math.sin(a) * r;
    pos[i * 3 + 2] = Math.random() * length;
    rnd[i] = Math.random();
  }
  geo.setAttribute('aPos', new THREE.InstancedBufferAttribute(pos, 3));
  geo.setAttribute('aRand', new THREE.InstancedBufferAttribute(rnd, 1));
  geo.instanceCount = count;

  const mat = new THREE.ShaderMaterial({
    uniforms: {
      uTravel: { value: 0 },
      uStretch: { value: 0 },
      uLen: { value: length },
      uWidth: { value: 0.11 },
      uIntensity: { value: 0 },
    },
    vertexShader: /* glsl */ `
      attribute vec2 corner; attribute vec3 aPos; attribute float aRand;
      uniform float uTravel; uniform float uStretch; uniform float uLen; uniform float uWidth; uniform float uIntensity;
      varying float vT; varying float vS; varying float vA; varying vec3 vCol;
      void main(){
        float z = mod(aPos.z + uTravel * (0.55 + 0.95 * aRand), uLen) - uLen;
        vec2 radial = normalize(aPos.xy);
        vec2 tang = vec2(-radial.y, radial.x);
        float len = 0.35 + uStretch * (0.42 + aRand * 0.95);
        float w = uWidth * (0.5 + aRand) * (0.55 + length(aPos.xy) * 0.02);
        vec3 p = vec3(aPos.xy + tang * corner.x * w, z - corner.y * len);
        vT = corner.y; vS = corner.x;
        vA = smoothstep(-uLen, -uLen * 0.52, z) * smoothstep(0.0, -10.0, z) * uIntensity;
        vec3 baseCol = mix(vec3(0.42, 0.72, 1.0), vec3(1.0, 0.93, 0.84), aRand * aRand);
        vCol = mix(baseCol, vec3(0.55, 0.86, 1.0), clamp(uStretch / 260.0, 0.0, 0.75));
        gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
      }`,
    fragmentShader: /* glsl */ `
      varying float vT; varying float vS; varying float vA; varying vec3 vCol;
      void main(){
        float a = vA * pow(1.0 - vT, 1.55) * (1.0 - vS * vS);
        gl_FragColor = vec4(vCol * a * 2.8, 1.0);
      }`,
    transparent: true,
    depthWrite: false,
    depthTest: false,
    blending: THREE.AdditiveBlending,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.frustumCulled = false;
  mesh.renderOrder = 20;
  return mesh;
}

/* ------------------------------------------------------------------ */
/* Hyperspace plasma wormhole tunnel + passing 3D shock rings          */
/* ------------------------------------------------------------------ */
export function makeTunnel(radius, length) {
  const geo = new THREE.CylinderGeometry(radius * 2.4, radius * 0.28, length, 96, 48, true);
  geo.rotateX(Math.PI / 2);
  geo.translate(0, 0, -length * 0.46);
  const mat = new THREE.ShaderMaterial({
    uniforms: { uTravel: { value: 0 }, uTime: { value: 0 }, uAlpha: { value: 0 } },
    vertexShader: /* glsl */ `
      varying vec2 vUv;
      void main(){
        vUv = uv;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
      }`,
    fragmentShader: NOISE + /* glsl */ `
      uniform float uTravel; uniform float uTime; uniform float uAlpha;
      varying vec2 vUv;
      void main(){
        float ang = vUv.x * 6.28318530718;
        vec2 ring = vec2(cos(ang + vUv.y * 1.8), sin(ang + vUv.y * 1.8));
        float zf = vUv.y * 10.0 - uTravel * 0.0032;
        float n1 = snoise(vec3(ring * 5.2, zf));
        float n2 = snoise(vec3(ring * 14.0, zf * 2.5 + 7.0));
        float n3 = snoise(vec3(ring * 2.2, zf * 0.45 - uTime * 0.28));
        float streak = pow(max(0.0, n1 * 0.56 + n2 * 0.44 + 0.32), 2.1);
        float pulseRings = pow(0.5 + 0.5 * sin(zf * 9.0 + n1 * 2.2), 5.0);
        float swell = 0.55 + 0.45 * n3;
        vec3 deep = vec3(0.03, 0.12, 0.46);
        vec3 cyan = vec3(0.28, 0.74, 1.0);
        vec3 warm = vec3(1.0, 0.74, 0.44);
        vec3 hot  = vec3(0.96, 0.98, 1.0);
        vec3 col = deep * swell + cyan * streak * 1.85 + warm * pulseRings * 0.55 + hot * pow(streak, 2.8) * 1.9;
        float ends = smoothstep(0.0, 0.22, vUv.y) * (1.0 - smoothstep(0.88, 1.0, vUv.y));
        gl_FragColor = vec4(col * ends * uAlpha, 1.0);
      }`,
    side: THREE.BackSide,
    transparent: true,
    depthWrite: false,
    depthTest: false,
    blending: THREE.AdditiveBlending,
  });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.frustumCulled = false;
  mesh.renderOrder = 10;
  return mesh;
}

/* ------------------------------------------------------------------ */
/* Near-field 3D dust: wraps around camera for true depth parallax     */
/* ------------------------------------------------------------------ */
export function makeDust(count) {
  const geo = new THREE.BufferGeometry();
  const p = new Float32Array(count * 3);
  const r = new Float32Array(count);
  for (let i = 0; i < count; i++) {
    p[i * 3] = Math.random();
    p[i * 3 + 1] = Math.random();
    p[i * 3 + 2] = Math.random();
    r[i] = Math.random();
  }
  geo.setAttribute('position', new THREE.BufferAttribute(p, 3));
  geo.setAttribute('aRand', new THREE.BufferAttribute(r, 1));
  const mat = new THREE.ShaderMaterial({
    uniforms: { uCam: { value: new THREE.Vector3() }, uBox: { value: 60 }, uOpacity: { value: 0.55 }, uPR: { value: 1 } },
    vertexShader: V_HEAD + /* glsl */ `
      attribute float aRand;
      uniform vec3 uCam; uniform float uBox; uniform float uOpacity; uniform float uPR;
      varying float vA;
      void main(){
        vec3 rel = mod(position * uBox - uCam, uBox) - uBox * 0.5;
        vec4 mv = viewMatrix * vec4(uCam + rel, 1.0);
        float dist = -mv.z;
        gl_PointSize = clamp(uPR * (0.7 + aRand * 1.5) * (uBox * 0.055 / max(dist, 0.001)), 0.6, 3.8 * uPR);
        vA = smoothstep(uBox * 0.5, uBox * 0.14, length(rel)) * smoothstep(0.0, uBox * 0.02, dist) * uOpacity * (0.3 + aRand * 0.7);
        gl_Position = projectionMatrix * mv;
        #include <logdepthbuf_vertex>
      }`,
    fragmentShader: F_HEAD + /* glsl */ `
      varying float vA;
      void main(){
        #include <logdepthbuf_fragment>
        float d = length(gl_PointCoord - 0.5);
        float a = smoothstep(0.5, 0.0, d) * vA;
        gl_FragColor = vec4(vec3(0.76, 0.84, 0.96) * a, 1.0);
      }`,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const pts = new THREE.Points(geo, mat);
  pts.frustumCulled = false;
  return pts;
}

/* ------------------------------------------------------------------ */
/* Final cinematic optical post-processing pass                        */
/* ------------------------------------------------------------------ */
export const PostShader = {
  uniforms: {
    tDiffuse: { value: null },
    uRes: { value: new THREE.Vector2(1, 1) },
    uTime: { value: 0 },
    uCA: { value: 0 },
    uBlur: { value: 0 },
    uFlash: { value: 0 },
    uShock: { value: 0 },
    uShockAmp: { value: 0 },
    uGlow: { value: 0 },
    uAnam: { value: 0 },
    uSun: { value: new THREE.Vector2(-10, -10) },
    uSunVis: { value: 0 },
    uVignette: { value: 0.52 },
    uGrain: { value: 0.022 },
  },
  vertexShader: /* glsl */ `
    varying vec2 vUv;
    void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
  fragmentShader: /* glsl */ `
    uniform sampler2D tDiffuse; uniform vec2 uRes; uniform float uTime;
    uniform float uCA; uniform float uBlur; uniform float uFlash; uniform float uShock; uniform float uShockAmp;
    uniform float uGlow; uniform float uAnam; uniform vec2 uSun; uniform float uSunVis;
    uniform float uVignette; uniform float uGrain;
    varying vec2 vUv;
    float hash(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
    void main(){
      float aspect = uRes.x / uRes.y;
      vec2 c = vec2(0.5);
      vec2 uv = vUv;
      vec2 d = uv - c;
      float r = length(d * vec2(aspect, 1.0));

      if (uShockAmp > 0.001) {
        float w = 0.095;
        float ring = smoothstep(uShock - w, uShock, r) * (1.0 - smoothstep(uShock, uShock + w, r));
        uv -= normalize(d + 1e-5) * ring * uShockAmp * 0.055;
      }

      vec3 col = vec3(0.0);
      vec2 caOff = (uv - c) * uCA * 0.018 * (0.3 + r);
      const int N = 14;
      for (int i = 0; i < N; i++) {
        float t = float(i) / float(N - 1);
        vec2 suv = c + (uv - c) * (1.0 - uBlur * 0.22 * t);
        col.r += texture2D(tDiffuse, suv + caOff).r;
        col.g += texture2D(tDiffuse, suv).g;
        col.b += texture2D(tDiffuse, suv - caOff).b;
      }
      col /= float(N);

      float rc = length((vUv - c) * vec2(aspect, 1.0));
      col += vec3(0.55, 0.8, 1.0) * uGlow * (exp(-rc * rc * 58.0) * 2.2 + exp(-rc * 5.8) * 0.26);
      float dy = abs(vUv.y - 0.5);
      col += vec3(0.38, 0.65, 1.0) * uAnam * exp(-dy * 260.0) * exp(-abs(vUv.x - 0.5) * 2.1) * 1.45;

      if (uSunVis > 0.001) {
        vec2 s = uSun;
        vec2 toC = c - s;
        float sdy = abs(vUv.y - s.y);
        col += vec3(1.0, 0.86, 0.7) * uSunVis * exp(-sdy * 320.0) * exp(-abs(vUv.x - s.x) * 3.4) * 0.85;
        for (int g = 1; g <= 5; g++) {
          float fg = float(g);
          vec2 gp = s + toC * (0.35 * fg);
          float gd = length((vUv - gp) * vec2(aspect, 1.0));
          float size = 0.015 + 0.028 * mod(fg * 1.7, 2.0);
          vec3 tint = mix(vec3(0.42, 0.72, 1.0), vec3(1.0, 0.62, 0.32), mod(fg, 2.0));
          col += tint * uSunVis * 0.048 * smoothstep(size, size * 0.4, gd);
        }
      }

      col = mix(col, vec3(2.6, 2.75, 3.0), clamp(uFlash, 0.0, 1.0));
      col *= mix(1.0, smoothstep(1.28, 0.24, r), uVignette);
      col += (hash(vUv * uRes + fract(uTime) * 100.0) - 0.5) * uGrain;
      gl_FragColor = vec4(max(col, 0.0), 1.0);
    }`,
};
