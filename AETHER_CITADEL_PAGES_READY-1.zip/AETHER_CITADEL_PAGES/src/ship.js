import * as THREE from 'three';

function makePlumeTexture() {
  const c = document.createElement('canvas');
  c.width = 64; c.height = 256;
  const g = c.getContext('2d');
  const gr = g.createLinearGradient(0, 0, 0, 256);
  gr.addColorStop(0.0, 'rgba(255, 255, 255, 1.0)');
  gr.addColorStop(0.18, 'rgba(130, 225, 255, 0.92)');
  gr.addColorStop(0.55, 'rgba(35, 130, 255, 0.42)');
  gr.addColorStop(1.0, 'rgba(10, 40, 140, 0.0)');
  g.fillStyle = gr;
  g.fillRect(0, 0, 64, 256);
  return new THREE.CanvasTexture(c);
}

function makeGlowTex() {
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const g = c.getContext('2d');
  const r = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  r.addColorStop(0, 'rgba(255,255,255,1)');
  r.addColorStop(0.25, 'rgba(120,220,255,0.8)');
  r.addColorStop(0.6, 'rgba(40,120,255,0.2)');
  r.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = r;
  g.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(c);
}

/**
 * High-Detail Sci-Fi Deep-Space Recon Corvette ("VALKYRIE-IX")
 * Forward axis is -Z (standard Three.js camera/object forward).
 * Span ~3.6 units, Length ~5.2 units.
 */
export function createStarship(envMap) {
  const root = new THREE.Group();
  const body = new THREE.Group(); // inner group for banking/pitching micro-dynamics
  root.add(body);

  const std = (o) => new THREE.MeshStandardMaterial({ envMap, envMapIntensity: 1.15, ...o });
  const armorWhite = std({ color: 0xd8e0ea, roughness: 0.28, metalness: 0.62 });
  const darkCarbon = std({ color: 0x202630, roughness: 0.36, metalness: 0.84 });
  const gunmetal = std({ color: 0x525d6d, roughness: 0.3, metalness: 0.82 });
  const goldTrim = std({ color: 0xe2ab48, roughness: 0.22, metalness: 0.95 });
  const canopyGlass = std({
    color: 0x0b192e, roughness: 0.08, metalness: 0.92,
    emissive: new THREE.Color(0.12, 0.45, 0.75), emissiveIntensity: 0.55,
  });

  const cyanGlow = new THREE.MeshBasicMaterial({ color: new THREE.Color(0.7, 2.8, 4.8) });
  const amberGlow = new THREE.MeshBasicMaterial({ color: new THREE.Color(4.2, 1.9, 0.5) });

  // 1. Sculpted sleek forward fuselage (-Z nose)
  const noseGeo = new THREE.ConeGeometry(0.48, 2.5, 6);
  noseGeo.rotateX(-Math.PI / 2);
  noseGeo.scale(1.35, 0.58, 1);
  const nose = new THREE.Mesh(noseGeo, armorWhite);
  nose.position.set(0, 0, -1.35);
  body.add(nose);

  const midHullGeo = new THREE.CylinderGeometry(0.62, 0.78, 2.4, 8);
  midHullGeo.rotateX(Math.PI / 2);
  midHullGeo.scale(1.28, 0.56, 1);
  const midHull = new THREE.Mesh(midHullGeo, armorWhite);
  midHull.position.set(0, 0, 0.55);
  body.add(midHull);

  // Dorsal spine & glowing quantum power strips
  const spine = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.22, 3.1), darkCarbon);
  spine.position.set(0, 0.32, 0.15);
  body.add(spine);

  const coreStrip = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.06, 2.8), cyanGlow);
  coreStrip.position.set(0, 0.44, 0.15);
  body.add(coreStrip);

  // Armored cockpit canopy
  const canopyGeo = new THREE.SphereGeometry(0.42, 20, 14);
  canopyGeo.scale(0.95, 0.52, 2.1);
  const canopy = new THREE.Mesh(canopyGeo, canopyGlass);
  canopy.position.set(0, 0.24, -0.68);
  body.add(canopy);

  // Forward canard winglets
  [-1, 1].forEach((s) => {
    const canard = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.04, 0.42), darkCarbon);
    canard.position.set(s * 0.72, -0.02, -1.1);
    canard.rotation.y = s * -0.38;
    canard.rotation.z = s * -0.08;
    body.add(canard);
  });

  // 2. Swept Variable-Geometry Delta Wings + Wingtip Warp Field Pylons
  [-1, 1].forEach((s) => {
    const wingShape = new THREE.Shape();
    wingShape.moveTo(0, 0);
    wingShape.lineTo(1.85, -0.95);
    wingShape.lineTo(1.95, -1.45);
    wingShape.lineTo(0.25, -1.15);
    wingShape.closePath();
    const wingGeo = new THREE.ExtrudeGeometry(wingShape, { depth: 0.06, bevelEnabled: true, bevelThickness: 0.02, bevelSize: 0.02 });
    wingGeo.rotateX(Math.PI / 2);
    if (s < 0) wingGeo.scale(-1, 1, 1);
    const wing = new THREE.Mesh(wingGeo, armorWhite);
    wing.position.set(s * 0.55, 0.02, -0.35);
    wing.rotation.z = s * -0.09;
    body.add(wing);

    // Wing leading-edge cyan energy trim
    const trim = new THREE.Mesh(new THREE.BoxGeometry(1.55, 0.03, 0.05), cyanGlow);
    trim.position.set(s * 1.42, -0.04, 0.12);
    trim.rotation.y = s * -0.46;
    trim.rotation.z = s * -0.09;
    body.add(trim);

    // Wingtip Alcubierre field nacelle pod
    const pod = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.14, 1.35, 14), gunmetal);
    pod.rotation.x = Math.PI / 2;
    pod.position.set(s * 2.38, -0.14, 0.85);
    body.add(pod);

    const podTip = new THREE.Mesh(new THREE.SphereGeometry(0.1, 12, 10), cyanGlow);
    podTip.position.set(s * 2.38, -0.14, 0.15);
    body.add(podTip);

    // Twin angled dorsal tail fins
    const fin = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.72, 0.95), darkCarbon);
    fin.position.set(s * 0.68, 0.44, 1.28);
    fin.rotation.z = s * -0.42;
    fin.rotation.x = -0.22;
    body.add(fin);
  });

  // 3. Dorsal Circular Alcubierre Warp Ring Arc
  const warpRing = new THREE.Mesh(new THREE.TorusGeometry(1.18, 0.065, 14, 56), goldTrim);
  warpRing.position.set(0, 0.08, 1.15);
  body.add(warpRing);
  const warpInner = new THREE.Mesh(new THREE.TorusGeometry(1.12, 0.028, 10, 56), cyanGlow);
  warpInner.position.set(0, 0.08, 1.15);
  body.add(warpInner);

  // 4. Twin Vectoring Ion Thruster Nozzles + Central Afterburner (+Z aft)
  const plumes = [];
  const plumeTex = makePlumeTexture();
  const glowTex = makeGlowTex();
  const plumeMat = new THREE.MeshBasicMaterial({
    map: plumeTex, color: new THREE.Color(1.2, 2.8, 4.8),
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
  });

  [[-0.44, 0, 1.82, 0.24], [0.44, 0, 1.82, 0.24], [0, 0.04, 1.88, 0.19]].forEach(([x, y, z, r]) => {
    const bell = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.72, r, 0.46, 20, 1, true), darkCarbon);
    bell.material.side = THREE.DoubleSide;
    bell.rotation.x = Math.PI / 2;
    bell.position.set(x, y, z);
    body.add(bell);

    const core = new THREE.Mesh(new THREE.CircleGeometry(r * 0.75, 20), new THREE.MeshBasicMaterial({ color: new THREE.Color(0.6, 1.6, 2.8) }));
    core.position.set(x, y, z + 0.21);
    body.add(core);

    const flare = new THREE.Sprite(new THREE.SpriteMaterial({
      map: glowTex, color: new THREE.Color(0.42, 1.15, 2.1),
      blending: THREE.AdditiveBlending, depthWrite: false, transparent: true,
    }));
    flare.position.set(x, y, z + 0.26);
    flare.scale.setScalar(r * 2.8);
    body.add(flare);

    // Crossed volumetric exhaust plume planes
    const pGroup = new THREE.Group();
    pGroup.position.set(x, y, z + 0.22);
    [0, Math.PI / 2].forEach((ang) => {
      const plane = new THREE.Mesh(new THREE.PlaneGeometry(r * 1.65, 2.4), plumeMat);
      plane.geometry.translate(0, -1.2, 0);
      plane.rotation.x = -Math.PI / 2;
      plane.rotation.z = ang;
      pGroup.add(plane);
    });
    body.add(pGroup);
    plumes.push({ pGroup, flare, baseR: r });
  });

  // Subtle dorsal fill light so the 3D starship armor gleams even on the dark side of planets
  const hullLight = new THREE.PointLight(0x88ccff, 3.2, 18, 1.5);
  hullLight.position.set(0, 3.2, 1.2);
  body.add(hullLight);

  // Nav wingtip strobes
  const portLight = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 8), amberGlow);
  portLight.position.set(-2.38, -0.14, 1.52);
  body.add(portLight);
  const stbdLight = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 8), cyanGlow);
  stbdLight.position.set(2.38, -0.14, 1.52);
  body.add(stbdLight);

  // 5. Ion Engine Exhaust Particle Ribbon Trail in World Space
  const MAX_TRAIL = 160;
  const trailPos = new Float32Array(MAX_TRAIL * 3);
  const trailAge = new Float32Array(MAX_TRAIL);
  for (let i = 0; i < MAX_TRAIL; i++) trailAge[i] = 999;
  const trailGeo = new THREE.BufferGeometry();
  trailGeo.setAttribute('position', new THREE.BufferAttribute(trailPos, 3));
  trailGeo.setAttribute('aAge', new THREE.BufferAttribute(trailAge, 1));
  trailGeo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e7);

  const trailMat = new THREE.ShaderMaterial({
    uniforms: { uPR: { value: 1 } },
    vertexShader: `
      #include <common>
      #include <logdepthbuf_pars_vertex>
      attribute float aAge;
      uniform float uPR;
      varying float vLife;
      void main(){
        vLife = clamp(1.0 - aAge / 1.35, 0.0, 1.0);
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        gl_PointSize = clamp(uPR * vLife * (38.0 / max(-mv.z, 1.0)), 0.0, 12.0 * uPR);
        gl_Position = projectionMatrix * mv;
        #include <logdepthbuf_vertex>
      }`,
    fragmentShader: `
      #include <common>
      #include <logdepthbuf_pars_fragment>
      varying float vLife;
      void main(){
        #include <logdepthbuf_fragment>
        if (vLife <= 0.01) discard;
        float d = length(gl_PointCoord - 0.5);
        float a = smoothstep(0.5, 0.0, d) * vLife * 0.75;
        vec3 col = mix(vec3(0.15, 0.55, 1.0), vec3(0.75, 0.96, 1.0), vLife);
        gl_FragColor = vec4(col * a * 1.8, 1.0);
      }`,
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
  });
  const trailPoints = new THREE.Points(trailGeo, trailMat);
  trailPoints.frustumCulled = false;

  let trailHead = 0;
  let emitAcc = 0;
  const _nozzleWorld = new THREE.Vector3();

  return {
    group: root,
    body,
    trailPoints,
    setPixelRatio(pr) {
      trailMat.uniforms.uPR.value = pr;
    },
    resetTrail(pos) {
      for (let i = 0; i < MAX_TRAIL; i++) {
        trailPos[i * 3] = pos.x;
        trailPos[i * 3 + 1] = pos.y;
        trailPos[i * 3 + 2] = pos.z;
        trailAge[i] = 999;
      }
      trailGeo.attributes.position.needsUpdate = true;
      trailGeo.attributes.aAge.needsUpdate = true;
    },
    update(dt, time, throttle = 0.2, boost = false, turnRateX = 0, turnRateY = 0) {
      // Dynamic banking roll & pitch feel on ship body
      const targetRoll = THREE.MathUtils.clamp(turnRateY * 0.65, -0.68, 0.68);
      const targetPitch = THREE.MathUtils.clamp(turnRateX * 0.35, -0.35, 0.35);
      body.rotation.z += (targetRoll - body.rotation.z) * Math.min(1, dt * 7.0);
      body.rotation.x += (targetPitch - body.rotation.x) * Math.min(1, dt * 7.0);

      warpInner.rotation.z = time * (boost ? 6.0 : 1.5);

      const power = (0.28 + throttle * 0.95) * (boost ? 1.85 : 1.0);
      const flicker = 0.9 + 0.1 * Math.sin(time * 48.0);
      for (const p of plumes) {
        p.pGroup.scale.set(0.8 + power * 0.2, 0.8 + power * 0.2, Math.max(0.15, power * flicker));
        p.flare.scale.setScalar(p.baseR * (2.1 + power * 1.4) * flicker);
      }

      // Update world-space ion particle trail
      for (let i = 0; i < MAX_TRAIL; i++) {
        if (trailAge[i] < 100) trailAge[i] += dt;
      }
      emitAcc += dt * (throttle > 0.05 ? (boost ? 75 : 42) : 12);
      while (emitAcc >= 1) {
        emitAcc -= 1;
        _nozzleWorld.set((Math.random() - 0.5) * 0.7, 0, 2.15);
        body.localToWorld(_nozzleWorld);
        trailPos[trailHead * 3 + 0] = _nozzleWorld.x;
        trailPos[trailHead * 3 + 1] = _nozzleWorld.y;
        trailPos[trailHead * 3 + 2] = _nozzleWorld.z;
        trailAge[trailHead] = 0;
        trailHead = (trailHead + 1) % MAX_TRAIL;
      }
      trailGeo.attributes.position.needsUpdate = true;
      trailGeo.attributes.aAge.needsUpdate = true;
    },
  };
}
