/**
 * Unified 3D Solar System Coordinate Space (logarithmicDepthBuffer enabled):
 * - Sun sits at [-120000, 12000, -40000]
 * - Earth sits at [0, 0, 0] (Radius = 180)
 * - Cosmic Citadel Megastructure Station sits in High Earth Orbit at [-260, 125, 380]
 *   -> From default far vantage, the station floats majestically against Earth's glowing night terminator & distant planets.
 *   -> In Station Architect mode, you orbit right up to the station, click individual 3D modules & explode-disassemble it!
 *   -> In 3rd-Person Starship mode, you pilot a sleek sci-fi corvette freely around the station, Earth, Moon, Asteroid Belt & all Solar System planets, or engage cinematic Quantum Warp to any planet!
 */

export const AU_KM = 1.496e8;
export const KM_PER_UNIT = 6371 / 180; // ~35.4 km per scene unit locally around Earth

export const BODIES = [
  {
    id: 'station',
    name: '苍穹堡垒 · 空间站',
    en: 'AETHER CITADEL · ORBITAL MEGASTRUCTURE',
    kind: 'station',
    au: 1.0,
    radius: 26, // Bounding radius of the 3D megastructure
    realRadius: 12.8, // 12.8 km deep-space citadel
    pos: [-240, 115, 390],
    orb: 'radial-gradient(circle at 35% 35%, #a8ecff, #2f7ec4 48%, #0c1f3d 82%)',
    desc: '人类深空工程巅峰「苍穹堡垒」宇宙级空间站。由量子奇点反应炉驱动，配备双层反向科里奥利重力环、曲速谐振天穹、八翼太阳风帆阵与等离子护盾粒子场。支持全 3D 独立拆解与单模块检视。',
    stats: [
      ['结构跨度', '12.8 km'],
      ['驻留轨道', '地球高轨 HEO'],
      ['核心动力', '量子奇点聚变炉'],
      ['人工重力', '0.98 G 双离心环'],
      ['可拆解模组', '8 大独立总成'],
      ['粒子护盾', '全频段在线'],
    ],
  },
  {
    id: 'earth',
    name: '地球',
    en: 'TERRA · EARTH',
    kind: 'planet',
    au: 1.0,
    radius: 180,
    realRadius: 6371,
    pos: [0, 0, 0],
    orb: 'radial-gradient(circle at 35% 35%, #9fd0ff, #2a6fb8 45%, #0b1d3a 75%)',
    desc: '蔚蓝摇篮。NASA 4K 海洋高光与大陆地貌交织，晨昏线横贯亚欧大陆，背光夜面千万座城市灯火如金色星网般沿着海岸与大河闪烁。',
    stats: [
      ['赤道半径', '6,371 km'],
      ['日心距离', '1.00 AU'],
      ['公转周期', '365.25 天'],
      ['自转周期', '23.93 小时'],
      ['大气成分', '78% N₂ · 21% O₂'],
      ['平均温度', '15 °C'],
    ],
  },
  {
    id: 'moon',
    name: '月球',
    en: 'LUNA · THE MOON',
    kind: 'moon',
    au: 1.0026,
    radius: 49,
    realRadius: 1737,
    pos: [1650, 260, -1450],
    orb: 'radial-gradient(circle at 35% 35%, #e9e9e6, #8e8d88 50%, #2a2a28 80%)',
    desc: '地球唯一的天然卫星。四十亿年陨石撞击铸就深邃环形山，回望深空，蓝色地球与轨道空间站在远处熠熠生辉。',
    stats: [
      ['平均半径', '1,737 km'],
      ['地月距离', '384,400 km'],
      ['公转周期', '27.32 天'],
      ['表面重力', '0.165 G'],
      ['昼夜温差', '-173 ~ 127 °C'],
      ['大气环境', '超高真空'],
    ],
  },
  {
    id: 'sun',
    name: '太阳',
    en: 'SOL · THE SUN',
    kind: 'star',
    au: 0.00465,
    radius: 2600,
    realRadius: 696340,
    pos: [-98000, 9500, -32000],
    orb: 'radial-gradient(circle at 38% 38%, #fffbe8, #ffae34 45%, #b83200 85%)',
    desc: '太阳系的引力与能量心脏。每秒将六亿吨氢聚变为氦，翻涌的日冕等离子体照亮八大行星与深空航道。',
    stats: [
      ['恒星半径', '696,340 km'],
      ['光谱类型', 'G2V 黄矮星'],
      ['光球温度', '5,500 °C'],
      ['日核温度', '1,500 万 °C'],
      ['质量占比', '99.86% 太阳系'],
      ['自转周期', '25.05 天'],
    ],
  },
  {
    id: 'mercury',
    name: '水星',
    en: 'MERCURY',
    kind: 'planet',
    au: 0.387,
    radius: 72,
    realRadius: 2439,
    pos: [-58000, 4200, -14000],
    orb: 'radial-gradient(circle at 35% 35%, #dcd6ce, #8c847b 52%, #2c2825 84%)',
    desc: '最靠近烈日的铁核岩质行星。卡洛里盆地布满古老裂谷，炙热白昼与极寒永夜在一线之间交替。',
    stats: [
      ['平均半径', '2,439 km'],
      ['日心距离', '0.39 AU'],
      ['公转周期', '87.97 天'],
      ['自转周期', '58.65 天'],
      ['表面温差', '-180 ~ 430 °C'],
      ['天然卫星', '0 颗'],
    ],
  },
  {
    id: 'venus',
    name: '金星',
    en: 'VENUS',
    kind: 'planet',
    au: 0.723,
    radius: 171,
    realRadius: 6051,
    pos: [-29000, 1900, 12500],
    orb: 'radial-gradient(circle at 35% 35%, #fff0cf, #d89f54 52%, #4e2f0e 84%)',
    desc: '浓密硫酸云层包裹的金色晨星。超旋大气层反射出丝绸般的光泽，地表潜藏着数千座古老火山。',
    stats: [
      ['平均半径', '6,051 km'],
      ['日心距离', '0.72 AU'],
      ['公转周期', '224.7 天'],
      ['自转方向', '逆行 243 天'],
      ['地表气压', '92 倍地球'],
      ['平均温度', '464 °C'],
    ],
  },
  {
    id: 'mars',
    name: '火星',
    en: 'MARS',
    kind: 'planet',
    au: 1.524,
    radius: 96,
    realRadius: 3390,
    pos: [22000, -1400, -24000],
    orb: 'radial-gradient(circle at 35% 35%, #f0a77a, #b5502a 50%, #3a1408 80%)',
    desc: '赤铁矿染红的荒原星球。21 公里高的奥林匹斯盾状火山刺破稀薄琥珀色大气，四千公里的水手号大峡谷横裂赤道。',
    stats: [
      ['平均半径', '3,390 km'],
      ['日心距离', '1.52 AU'],
      ['公转周期', '687 天'],
      ['自转周期', '24.62 小时'],
      ['天然卫星', '2 颗'],
      ['平均温度', '-63 °C'],
    ],
  },
  {
    id: 'jupiter',
    name: '木星',
    en: 'JUPITER',
    kind: 'planet',
    au: 5.203,
    radius: 1380,
    realRadius: 69911,
    pos: [68000, 4800, -62000],
    orb: 'radial-gradient(circle at 35% 35%, #f3e3c8, #c49a6c 50%, #4a2e18 80%)',
    desc: '太阳系的气态霸主。氨冰激流云带与吞噬地球尺度的大红斑超级风暴日夜咆哮，前景火山卫星木卫一更显其窒息巨物感。',
    stats: [
      ['赤道半径', '69,911 km'],
      ['日心距离', '5.20 AU'],
      ['公转周期', '11.86 年'],
      ['自转周期', '9.93 小时'],
      ['已知卫星', '95 颗'],
      ['云顶温度', '-110 °C'],
    ],
  },
  {
    id: 'saturn',
    name: '土星',
    en: 'SATURN',
    kind: 'planet',
    au: 9.537,
    radius: 1160,
    realRadius: 58232,
    pos: [128000, -9200, -108000],
    orb: 'radial-gradient(circle at 35% 35%, #f6e7c1, #c9a96b 50%, #4d3a1c 80%)',
    desc: '戴着璀璨冰晶王冠的气态巨行星。绵延 28 万公里的卡西尼环缝与亿万冰粒在恒星直射下投出锐利巨影。',
    stats: [
      ['赤道半径', '58,232 km'],
      ['日心距离', '9.54 AU'],
      ['光环跨度', '282,000 km'],
      ['自转周期', '10.7 小时'],
      ['已知卫星', '146 颗'],
      ['云顶温度', '-140 °C'],
    ],
  },
  {
    id: 'uranus',
    name: '天王星',
    en: 'URANUS',
    kind: 'planet',
    au: 19.19,
    radius: 520,
    realRadius: 25362,
    pos: [195000, 12000, -162000],
    orb: 'radial-gradient(circle at 35% 35%, #d6f9ff, #68bcc9 52%, #153e4a 84%)',
    desc: '侧躺公转的青碧冰巨星。97.7° 极端轴倾角使其两极轮流直面太阳长达四十二年，纤细暗环斜悬深空。',
    stats: [
      ['赤道半径', '25,362 km'],
      ['日心距离', '19.19 AU'],
      ['公转周期', '84.02 年'],
      ['自转倾角', '97.77°'],
      ['已知卫星', '28 颗'],
      ['最低温度', '-224 °C'],
    ],
  },
  {
    id: 'neptune',
    name: '海王星',
    en: 'NEPTUNE',
    kind: 'planet',
    au: 30.07,
    radius: 495,
    realRadius: 24622,
    pos: [268000, -14000, -225000],
    orb: 'radial-gradient(circle at 35% 35%, #a9c8ff, #3d64c9 50%, #0c1a48 80%)',
    desc: '太阳系幽蓝边疆。距地球逾四十亿公里，阳光在此微弱如暮星，时速两千公里的超音速甲烷飓风席卷深海冰云。',
    stats: [
      ['赤道半径', '24,622 km'],
      ['日心距离', '30.07 AU'],
      ['公转周期', '164.8 年'],
      ['自转周期', '16.11 小时'],
      ['最高风速', '2,100 km/h'],
      ['云顶温度', '-214 °C'],
    ],
  },
];

export const STATION_MODULES = [
  {
    id: 'core',
    name: '量子奇点聚变炉芯',
    en: 'QUANTUM SINGULARITY REACTOR',
    role: '主能源与引力锚定中枢',
    spec: '输出功率 4.8 TW · 磁约束反物质等离子腔',
    explode: [0, 0, 0],
  },
  {
    id: 'ringA',
    name: '外层科里奥利生态重力环',
    en: 'OUTER HABITATION CENTRIFUGE',
    role: '1.0G 生态居住区与全景穹顶花园',
    spec: '直径 5.6 km · 转速 1.8 RPM · 可容纳 24,000 名宇航员',
    explode: [0, 0, 14],
  },
  {
    id: 'ringB',
    name: '内层科研与医疗离心环',
    en: 'INNER BIO-SCIENCE CENTRIFUGE',
    role: '0.6G 低重材料实验室与深空医疗中心',
    spec: '直径 3.6 km · 反向抵消扭矩旋转设计',
    explode: [0, 0, -13],
  },
  {
    id: 'command',
    name: '天穹指挥塔与深空相控阵',
    en: 'ZENITH COMMAND SPIRE & ARRAY',
    role: '全星系超光速量子通讯与航道调度中枢',
    spec: '360° 全景舰桥 · 18 AU 级子空间信标阵列',
    explode: [0, 17, 0],
  },
  {
    id: 'dock',
    name: '六向星际母舰停泊港',
    en: 'HEX-RADIAL STARSHIP DOCKING HUB',
    role: '重型巡洋舰电磁弹射与气密停泊廊桥',
    spec: '6 组磁力捕获泊位 · 含等离子导流信标',
    explode: [0, -16, 0],
  },
  {
    id: 'solarPort',
    name: '左舷太阳风量子帆阵',
    en: 'PORT PHOTOVOLTAIC WING MATRIX',
    role: '高效多结砷化镓聚光阵与粒子收集翼',
    spec: '四联装自动追日铰链 · 金箔 Kapton 柔性基板',
    explode: [-22, 0, 0],
  },
  {
    id: 'solarStbd',
    name: '右舷太阳风量子帆阵',
    en: 'STARBOARD PHOTOVOLTAIC MATRIX',
    role: '右舷冗余电力矩阵与高能宇宙射线偏转翼',
    spec: '四联装自动追日铰链 · 峰值转换率 68%',
    explode: [22, 0, 0],
  },
  {
    id: 'warpDrive',
    name: '尾部超空间曲速谐振环',
    en: 'AFT ALCUBIERRE WARP RESONATOR',
    role: '维持空间站轨道曲率护盾与星门折跃锚点',
    spec: '双联装液态氦闭式散热翼 + 负能量场发生环',
    explode: [0, 4, -22],
  },
];

export function distanceBetweenKm(a, b) {
  const pair = [a.id, b.id].sort().join('-');
  if (pair === 'earth-station') return 35800;
  if (pair === 'earth-moon' || pair === 'moon-station') return 384400;
  const dAu = Math.abs(a.au - b.au);
  if (dAu < 0.001) return 42000;
  return dAu * AU_KM;
}

export function formatKm(km) {
  if (km >= 1e8) return (km / 1e8).toFixed(2) + ' 亿 km';
  if (km >= 1e4) return (km / 1e4).toFixed(1) + ' 万 km';
  return Math.max(1, Math.round(km)).toLocaleString('en-US') + ' km';
}
