import * as THREE from 'three';
import { STATION_MODULES } from './data.js';

function makeHullMaps() {
  const c = document.createElement('canvas');
  c.width = c.height = 512;
  const g = c.getContext('2d');
  g.fillStyle = '#808080';
  g.fillRect(0, 0, 512, 512);

  // Sci-fi aerospace hull plating seams & greeble panels
  g.strokeStyle = '#3a3a3a';
  g.lineWidth = 2;
  for (let i = 0; i <= 512; i += 64) {
    g.beginPath(); g.moveTo(i, 0); g.lineTo(i, 512); g.stroke();
    g.beginPath(); g.moveTo(0, i); g.lineTo(512, i); g.stroke();
  }
  for (let i = 0; i < 90; i++) {
    const x = ((i * 79) % 16) * 32 + 3;
    const y = ((i * 53) % 16) * 32 + 3;
    g.fillStyle = i % 3 === 0 ? '#a2a2a2' : '#696969';
    g.fillRect(x, y, 26, 26);
  }
  const bump = new THREE.CanvasTexture(c);
  bump.wrapS = bump.wrapT = THREE.RepeatWrapping;
  bump.repeat.set(3, 3);
  return bump;
}

function makeCityRingLights() {
  const c = document.createElement('canvas');
  c.width = 1024; c.height = 128;
  const g = c.getContext('2d');
  g.fillStyle = '#05080f';
  g.fillRect(0, 0, 1024, 128);
  for (let x = 0; x < 1024; x += 6) {
    for (let y = 18; y < 110; y += 10) {
      if (((x * 13 + y * 31) % 11) > 3) {
        g.fillStyle = ((x + y) % 5 === 0) ? '#88e5ff' : '#ffd89a';
        g.fillRect(x, y, 3, 5);
      }
    }
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(8, 1);
  return t;
}

function makeSolarCanvas() {
  const c = document.createElement('canvas');
  c.width = 512; c.height = 1024;
  const g = c.getContext('2d');
  const gr = g.createLinearGradient(0, 0, 512, 1024);
  gr.addColorStop(0, '#0f2547');
  gr.addColorStop(0.5, '#09162e');
  gr.addColorStop(1, '#15315c');
  g.fillStyle = gr;
  g.fillRect(0, 0, 512, 1024);

  g.strokeStyle = 'rgba(110, 195, 255, 0.36)';
  g.lineWidth = 1;
  for (let x = 0; x <= 512; x += 16) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, 1024); g.stroke(); }
  for (let y = 0; y <= 1024; y += 16) { g.beginPath(); g.moveTo(0, y); g.lineTo(512, y); g.stroke(); }

  // Gold quantum busbars
  g.strokeStyle = 'rgba(236, 186, 88, 0.95)';
  g.lineWidth = 6;
  for (let y = 0; y <= 1024; y += 128) { g.beginPath(); g.moveTo(0, y); g.lineTo(512, y); g.stroke(); }
  g.strokeRect(3, 3, 506, 1018);
  g.fillStyle = 'rgba(220, 172, 76, 0.9)';
  g.fillRect(248, 0, 16, 1024);

  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

function makeGlowSpriteTex() {
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const g = c.getContext('2d');
  const r = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  r.addColorStop(0, 'rgba(255,255,255,1)');
  r.addColorStop(0.22, 'rgba(150,225,255,0.75)');
  r.addColorStop(0.55, 'rgba(50,140,255,0.18)');
  r.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = r;
  g.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(c);
}

/**
 * Cosmic-Class Sci-Fi Megastructure Space Station ("Aether Citadel")
 * - 8 independently interactive, selectable & explode-disassemblable 3D assemblies
 * - Sci-fi quantum particle vortex, plasma shield shell & holographic energy conduits
 */
export function createCosmicStation(envMap) {
  const root = new THREE.Group();
  const hullBump = makeHullMaps();
  const winMap = makeCityRingLights();
  const solarMap = makeSolarCanvas();
  const glowTex = makeGlowSpriteTex();

  const std = (o) => new THREE.MeshStandardMaterial({ envMap, envMapIntensity: 0.95, ...o });
  const titanium = std({ color: 0xdce3ec, roughness: 0.36, metalness: 0.45, bumpMap: hullBump, bumpScale: 0.03 });
  const gunmetal = std({ color: 0x4b5563, roughness: 0.32, metalness: 0.82, bumpMap: hullBump, bumpScale: 0.025 });
  const darkAlloy = std({ color: 0x1e242d, roughness: 0.44, metalness: 0.78 });
  const goldFoil = std({ color: 0xe0a946, roughness: 0.22, metalness: 0.96, envMapIntensity: 1.35 });
  const habWall = std({
    color: 0xc9d2de, roughness: 0.42, metalness: 0.52,
    emissiveMap: winMap, emissive: new THREE.Color(1.4, 1.25, 1.0), emissiveIntensity: 1.35,
  });
  const solarMat = std({
    map: solarMap, color: 0xffffff, roughness: 0.2, metalness: 0.72,
    envMapIntensity: 1.4, side: THREE.DoubleSide,
  });
  const radiatorMat = std({
    color: 0xf4ece6, roughness: 0.5, metalness: 0.2,
    emissive: new THREE.Color(0.35, 0.08, 0.02), emissiveIntensity: 0.35, side: THREE.DoubleSide,
  });

  const cyanPlasma = new THREE.MeshBasicMaterial({ color: new THREE.Color(0.65, 2.5, 4.2) });
  const amberCore = new THREE.MeshBasicMaterial({ color: new THREE.Color(3.8, 1.9, 0.55) });
  const holoMat = new THREE.ShaderMaterial({
    uniforms: { uTime: { value: 0 }, uColor: { value: new THREE.Color(0.22, 0.78, 1.0) }, uAlpha: { value: 0.38 } },
    vertexShader: `
      #include <common>
      #include <logdepthbuf_pars_vertex>
      varying vec3 vN; varying vec3 vV; varying vec2 vUv;
      void main(){
        vUv = uv;
        vec4 wp = modelMatrix * vec4(position, 1.0);
        vN = normalize(mat3(modelMatrix) * normal);
        vV = normalize(cameraPosition - wp.xyz);
        gl_Position = projectionMatrix * viewMatrix * wp;
        #include <logdepthbuf_vertex>
      }`,
    fragmentShader: `
      #include <common>
      #include <logdepthbuf_pars_fragment>
      uniform float uTime; uniform vec3 uColor; uniform float uAlpha;
      varying vec3 vN; varying vec3 vV; varying vec2 vUv;
      void main(){
        #include <logdepthbuf_fragment>
        float fres = pow(1.0 - abs(dot(vN, vV)), 4.2);
        float scan = 0.7 + 0.3 * sin(vUv.y * 90.0 - uTime * 4.5);
        gl_FragColor = vec4(uColor * fres * 1.35 * scan * uAlpha, 1.0);
      }`,
    transparent: true, depthWrite: false, side: THREE.FrontSide, blending: THREE.AdditiveBlending,
  });

  // Map of module id -> { group, basePos, explodeVec, meta, highlightMeshes }
  const moduleMap = {};
  const pickables = [];

  for (const meta of STATION_MODULES) {
    const g = new THREE.Group();
    g.name = meta.id;
    g.userData.moduleId = meta.id;
    root.add(g);
    moduleMap[meta.id] = {
      group: g,
      meta,
      explodeVec: new THREE.Vector3(...meta.explode),
      curOffset: new THREE.Vector3(),
      spinTarget: null,
    };
  }

  const addMesh = (modId, geo, mat, pos = [0, 0, 0], rot = [0, 0, 0], scale = [1, 1, 1]) => {
    const m = new THREE.Mesh(geo, mat);
    m.position.set(...pos);
    m.rotation.set(...rot);
    m.scale.set(...scale);
    m.userData.moduleId = modId;
    moduleMap[modId].group.add(m);
    pickables.push(m);
    return m;
  };

  /* 1. CORE — Quantum Singularity Fusion Reactor + Containment Cages */
  {
    const id = 'core';
    // Singularity glowing sun-sphere inside magnetic cage
    const coreOrb = addMesh(id, new THREE.IcosahedronGeometry(1.45, 4), cyanPlasma);
    const coreShell = addMesh(id, new THREE.IcosahedronGeometry(1.95, 2), new THREE.MeshBasicMaterial({
      color: new THREE.Color(0.4, 1.8, 3.2), wireframe: true, transparent: true, opacity: 0.55,
    }));
    moduleMap[id].coreShell = coreShell;
    moduleMap[id].coreOrb = coreOrb;

    // 3 Gimbaled magnetic containment rings
    const gimbals = [];
    [2.55, 3.05, 3.55].forEach((r, idx) => {
      const m = addMesh(id, new THREE.TorusGeometry(r, 0.14, 16, 64), idx === 1 ? goldFoil : gunmetal);
      gimbals.push(m);
    });
    moduleMap[id].gimbals = gimbals;

    // Central axial spinal column
    addMesh(id, new THREE.CylinderGeometry(0.85, 0.85, 11.5, 32), gunmetal);
    [-4.2, 4.2].forEach((y) => {
      addMesh(id, new THREE.CylinderGeometry(1.55, 1.2, 1.4, 24), titanium, [0, y, 0]);
      addMesh(id, new THREE.TorusGeometry(1.58, 0.08, 12, 48), cyanPlasma, [0, y + (y > 0 ? 0.65 : -0.65), 0], [Math.PI / 2, 0, 0]);
    });

    // Core glow sprite
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({
      map: glowTex, color: new THREE.Color(0.6, 2.2, 4.0), blending: THREE.AdditiveBlending, depthWrite: false, transparent: true,
    }));
    sp.scale.setScalar(9.5);
    moduleMap[id].group.add(sp);
  }

  /* 2. OUTER HABITATION CENTRIFUGE RING (Diameter ~21 units) */
  {
    const id = 'ringA';
    const spinner = new THREE.Group();
    moduleMap[id].group.add(spinner);
    moduleMap[id].spinTarget = spinner;

    const R = 10.6;
    const mainTorus = new THREE.Mesh(new THREE.TorusGeometry(R, 0.78, 28, 128), habWall);
    mainTorus.userData.moduleId = id;
    spinner.add(mainTorus);
    pickables.push(mainTorus);

    // Outer armor ribs & glowing biodome segments
    for (let i = 0; i < 24; i++) {
      const a = (i / 24) * Math.PI * 2;
      const clamp = new THREE.Mesh(new THREE.BoxGeometry(0.55, 1.85, 1.85), i % 3 === 0 ? goldFoil : gunmetal);
      clamp.position.set(Math.cos(a) * R, Math.sin(a) * R, 0);
      clamp.rotation.z = a + Math.PI / 2;
      clamp.userData.moduleId = id;
      spinner.add(clamp);
      pickables.push(clamp);
    }
    // 6 heavy radial elevator spokes + central hub bearing
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const spoke = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.28, R - 1.6, 16), titanium);
      spoke.position.set(Math.cos(a) * (R * 0.5 + 0.6), Math.sin(a) * (R * 0.5 + 0.6), 0);
      spoke.rotation.z = a - Math.PI / 2;
      spoke.userData.moduleId = id;
      spinner.add(spoke);
      pickables.push(spoke);
    }
    const hub = new THREE.Mesh(new THREE.TorusGeometry(1.9, 0.28, 16, 48), goldFoil);
    hub.userData.moduleId = id;
    spinner.add(hub);
    pickables.push(hub);

    // Twin cyan plasma trim rings flanking the outer torus
    [-0.82, 0.82].forEach((z) => {
      const tr = new THREE.Mesh(new THREE.TorusGeometry(R, 0.055, 10, 128), cyanPlasma);
      tr.position.z = z;
      spinner.add(tr);
    });
  }

  /* 3. INNER RESEARCH CENTRIFUGE RING (Counter-rotating, Z-offset / angled) */
  {
    const id = 'ringB';
    const spinner = new THREE.Group();
    spinner.position.z = -3.4;
    moduleMap[id].group.add(spinner);
    moduleMap[id].spinTarget = spinner;

    const R = 6.8;
    const torus = new THREE.Mesh(new THREE.TorusGeometry(R, 0.52, 24, 96), habWall);
    torus.userData.moduleId = id;
    spinner.add(torus);
    pickables.push(torus);

    for (let i = 0; i < 4; i++) {
      const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
      const spoke = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, R - 1.2, 12), gunmetal);
      spoke.position.set(Math.cos(a) * (R * 0.5 + 0.4), Math.sin(a) * (R * 0.5 + 0.4), 0);
      spoke.rotation.z = a - Math.PI / 2;
      spoke.userData.moduleId = id;
      spinner.add(spoke);
      pickables.push(spoke);
    }
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2;
      const pod = new THREE.Mesh(new THREE.SphereGeometry(0.68, 18, 14), i % 2 === 0 ? titanium : goldFoil);
      pod.position.set(Math.cos(a) * R, Math.sin(a) * R, 0);
      pod.userData.moduleId = id;
      spinner.add(pod);
      pickables.push(pod);
    }
    const collar = new THREE.Mesh(new THREE.CylinderGeometry(1.35, 1.35, 1.4, 28), gunmetal);
    collar.rotation.x = Math.PI / 2;
    collar.userData.moduleId = id;
    spinner.add(collar);
    pickables.push(collar);
  }

  /* 4. ZENITH COMMAND SPIRE & PHASED DEEP-SPACE ARRAY (+Y) */
  {
    const id = 'command';
    addMesh(id, new THREE.CylinderGeometry(0.55, 1.35, 5.6, 8), titanium, [0, 7.6, 0]);
    addMesh(id, new THREE.CylinderGeometry(1.95, 1.15, 1.2, 32), habWall, [0, 10.6, 0]);
    addMesh(id, new THREE.CylinderGeometry(0.12, 0.55, 4.8, 16), goldFoil, [0, 13.5, 0]);
    addMesh(id, new THREE.TorusGeometry(2.1, 0.06, 12, 64), cyanPlasma, [0, 10.9, 0], [Math.PI / 2, 0, 0]);

    // Triple parabolic deep-space dishes
    for (let i = 0; i < 3; i++) {
      const a = (i / 3) * Math.PI * 2;
      const dish = addMesh(
        id,
        new THREE.SphereGeometry(0.95, 24, 14, 0, Math.PI * 2, 0, 0.72),
        titanium,
        [Math.cos(a) * 1.85, 8.8, Math.sin(a) * 1.85],
        [0.45, -a, 0]
      );
      dish.material = dish.material.clone();
      dish.material.side = THREE.DoubleSide;
    }
    // Holographic sensor dome above bridge
    addMesh(id, new THREE.SphereGeometry(1.45, 24, 16, 0, Math.PI * 2, 0, Math.PI * 0.5), holoMat, [0, 11.2, 0]);
  }

  /* 5. NADIR HEX-RADIAL STARSHIP DOCKING HUB (-Y) */
  {
    const id = 'dock';
    addMesh(id, new THREE.CylinderGeometry(1.45, 1.85, 4.2, 24), gunmetal, [0, -7.2, 0]);
    addMesh(id, new THREE.CylinderGeometry(2.8, 2.2, 1.3, 6), titanium, [0, -9.8, 0]);

    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const arm = addMesh(
        id,
        new THREE.BoxGeometry(3.4, 0.52, 0.72),
        gunmetal,
        [Math.cos(a) * 3.6, -9.8, Math.sin(a) * 3.6],
        [0, -a, 0]
      );
      void arm;
      // Glowing magnetic docking collar at end of each pier
      addMesh(
        id,
        new THREE.TorusGeometry(0.56, 0.07, 12, 32),
        i % 2 === 0 ? cyanPlasma : amberCore,
        [Math.cos(a) * 5.45, -9.8, Math.sin(a) * 5.45],
        [0, -a + Math.PI / 2, 0]
      );
    }
    // Approach tractor-beam cone
    addMesh(id, new THREE.ConeGeometry(2.1, 4.5, 32, 1, true), holoMat, [0, -12.7, 0], [Math.PI, 0, 0]);
  }

  /* 6 & 7. PORT & STARBOARD QUANTUM SOLAR SAIL WINGS (-X / +X) */
  ['solarPort', 'solarStbd'].forEach((id, idx) => {
    const dir = idx === 0 ? -1 : 1;
    // Heavy main truss boom extending outside outer ring
    addMesh(id, new THREE.BoxGeometry(10.5, 0.55, 0.55), gunmetal, [dir * 16.4, 0, -1.7]);
    addMesh(id, new THREE.CylinderGeometry(0.65, 0.65, 1.2, 20), goldFoil, [dir * 11.5, 0, -1.7], [0, 0, Math.PI / 2]);

    const wingPivot = new THREE.Group();
    wingPivot.position.set(dir * 17.2, 0, -1.7);
    moduleMap[id].group.add(wingPivot);
    moduleMap[id].wingPivot = wingPivot;

    [-3.2, 3.2].forEach((ox) => {
      const mastX = ox * 0.85;
      const mast = new THREE.Mesh(new THREE.BoxGeometry(0.16, 15.6, 0.16), darkAlloy);
      mast.position.x = mastX;
      mast.userData.moduleId = id;
      wingPivot.add(mast);
      pickables.push(mast);

      [-1, 1].forEach((sy) => {
        const panel = new THREE.Mesh(new THREE.BoxGeometry(2.35, 6.8, 0.04), solarMat);
        panel.position.set(mastX, sy * 4.15, 0);
        panel.userData.moduleId = id;
        wingPivot.add(panel);
        pickables.push(panel);

        const tip = new THREE.Mesh(new THREE.BoxGeometry(2.45, 0.14, 0.14), goldFoil);
        tip.position.set(mastX, sy * 7.65, 0);
        tip.userData.moduleId = id;
        wingPivot.add(tip);
        pickables.push(tip);
      });
    });
  });

  /* 8. AFT ALCUBIERRE WARP RESONATOR & THERMAL RADIATORS (-Z) */
  {
    const id = 'warpDrive';
    addMesh(id, new THREE.CylinderGeometry(1.1, 1.6, 6.8, 24), gunmetal, [0, 0, -7.8], [Math.PI / 2, 0, 0]);
    // Giant Alcubierre negative-energy warp ring
    addMesh(id, new THREE.TorusGeometry(4.6, 0.36, 20, 80), darkAlloy, [0, 0, -10.8]);
    addMesh(id, new THREE.TorusGeometry(4.6, 0.1, 12, 80), cyanPlasma, [0, 0, -11.2]);
    addMesh(id, new THREE.CylinderGeometry(0.4, 1.35, 2.2, 28), goldFoil, [0, 0, -11.6], [Math.PI / 2, 0, 0]);
    addMesh(id, new THREE.SphereGeometry(0.92, 20, 16), cyanPlasma, [0, 0, -12.4]);

    // 4 Swept thermal rejection radiator fins
    for (let i = 0; i < 4; i++) {
      const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
      addMesh(
        id,
        new THREE.BoxGeometry(5.2, 0.06, 2.4),
        radiatorMat,
        [Math.cos(a) * 3.4, Math.sin(a) * 3.4, -8.2],
        [0, 0, a]
      );
    }
  }

  /* ------------------------------------------------------------------ */
  /* Exterior Sci-Fi Quantum Particle Field & Energy Shield             */
  /* ------------------------------------------------------------------ */
  const pCount = 2200;
  const pGeo = new THREE.BufferGeometry();
  const pSeed = new Float32Array(pCount * 4);
  const pDummyPos = new Float32Array(pCount * 3);
  for (let i = 0; i < pCount; i++) {
    pSeed[i * 4 + 0] = Math.random() * Math.PI * 2; // angle
    pSeed[i * 4 + 1] = 5.5 + Math.pow(Math.random(), 0.7) * 18.5; // orbit radius
    pSeed[i * 4 + 2] = (Math.random() - 0.5) * 22.0; // axial height
    pSeed[i * 4 + 3] = Math.random(); // color & speed seed
    pDummyPos[i * 3] = pSeed[i * 4 + 1];
  }
  pGeo.setAttribute('position', new THREE.BufferAttribute(pDummyPos, 3));
  pGeo.setAttribute('aSeed', new THREE.BufferAttribute(pSeed, 4));
  pGeo.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 60);

  const particleMat = new THREE.ShaderMaterial({
    uniforms: { uTime: { value: 0 }, uPR: { value: 1 }, uExplode: { value: 0 } },
    vertexShader: `
      #include <common>
      #include <logdepthbuf_pars_vertex>
      attribute vec4 aSeed;
      uniform float uTime; uniform float uPR; uniform float uExplode;
      varying vec3 vCol; varying float vAlpha;
      void main(){
        float speed = (0.18 + aSeed.w * 0.45) * (aSeed.w > 0.5 ? 1.0 : -1.0);
        float ang = aSeed.x + uTime * speed;
        float rad = (aSeed.y + 1.4 * sin(uTime * 0.9 + aSeed.x * 3.0)) * (1.0 + uExplode * 0.85);
        float zWave = aSeed.z + 2.2 * cos(uTime * 0.6 + aSeed.y);
        // Spiral stream + outer toroidal flux
        vec3 lp = vec3(cos(ang) * rad, sin(ang) * rad, zWave * 0.55);
        if (aSeed.w > 0.72) {
          // Axial quantum jet particles along Y spire
          float jetY = mod(aSeed.z + 11.0 + uTime * 6.0, 28.0) - 14.0;
          float jr = 0.6 + 2.2 * abs(jetY) / 14.0;
          lp = vec3(cos(ang * 3.0) * jr, jetY, sin(ang * 3.0) * jr);
        }
        vCol = mix(vec3(0.28, 0.82, 1.0), vec3(1.0, 0.78, 0.38), pow(aSeed.w, 2.2));
        vAlpha = 0.45 + 0.55 * sin(uTime * 2.8 + aSeed.x * 7.0);
        vec4 mv = modelViewMatrix * vec4(lp, 1.0);
        gl_PointSize = clamp(uPR * (1.5 + aSeed.w * 2.8) * (42.0 / max(-mv.z, 4.0)), 1.2, 7.0 * uPR);
        gl_Position = projectionMatrix * mv;
        #include <logdepthbuf_vertex>
      }`,
    fragmentShader: `
      #include <common>
      #include <logdepthbuf_pars_fragment>
      varying vec3 vCol; varying float vAlpha;
      void main(){
        #include <logdepthbuf_fragment>
        float d = length(gl_PointCoord - 0.5);
        float a = smoothstep(0.5, 0.02, d) * vAlpha;
        gl_FragColor = vec4(vCol * a * 1.9, 1.0);
      }`,
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
  });
  const particleField = new THREE.Points(pGeo, particleMat);
  particleField.frustumCulled = false;
  root.add(particleField);

  // Delicate geodesic energy-field wireframe lattice (only visible as ultra-fine sci-fi rim lines)
  const shieldMesh = new THREE.Mesh(
    new THREE.IcosahedronGeometry(24.5, 2),
    new THREE.MeshBasicMaterial({
      color: new THREE.Color(0.22, 0.72, 1.0),
      wireframe: true, transparent: true, opacity: 0.09,
      blending: THREE.AdditiveBlending, depthWrite: false,
    })
  );
  root.add(shieldMesh);

  // Navigation & strobe beacons visible from far orbit
  const beacons = [
    [-22.5, 0, -1.7, new THREE.Color(6, 0.4, 0.3), 1.7, 0.0],
    [22.5, 0, -1.7, new THREE.Color(0.3, 6, 0.7), 1.7, 0.85],
    [0, 16.2, 0, new THREE.Color(4, 5, 6), 2.4, 0.2],
    [0, -15.2, 0, new THREE.Color(6, 4.2, 1.5), 2.1, 1.1],
  ].map(([x, y, z, col, period, phase]) => {
    const s = new THREE.Sprite(new THREE.SpriteMaterial({
      map: glowTex, color: col.clone(), blending: THREE.AdditiveBlending,
      depthWrite: false, sizeAttenuation: false, transparent: true,
    }));
    s.position.set(x, y, z);
    s.scale.setScalar(0.016);
    s.userData = { base: col, period, phase };
    root.add(s);
    return s;
  });

  // Disassembly & selection state
  let explodeAmount = 0;
  let targetExplode = 0;
  let selectedId = null;
  const _targetVec = new THREE.Vector3();

  // Holographic energy tether lines drawn from core to exploded modules when disassembled
  const tetherGeo = new THREE.BufferGeometry();
  const tetherPositions = new Float32Array(STATION_MODULES.length * 2 * 3);
  tetherGeo.setAttribute('position', new THREE.BufferAttribute(tetherPositions, 3));
  const tetherLines = new THREE.LineSegments(
    tetherGeo,
    new THREE.LineBasicMaterial({ color: 0x4cc9ff, transparent: true, opacity: 0, blending: THREE.AdditiveBlending })
  );
  tetherLines.frustumCulled = false;
  root.add(tetherLines);

  function setSelected(modId) {
    selectedId = modId;
    // Highlight selected module with subtle cyan rim boost
    for (const [id, entry] of Object.entries(moduleMap)) {
      const isSel = id === selectedId;
      entry.group.traverse((obj) => {
        if (obj.isMesh && obj.material && obj.material.isMeshStandardMaterial) {
          if (!obj.userData.origEmissive) {
            obj.userData.origEmissive = obj.material.emissive.clone();
            obj.userData.origEmissiveInt = obj.material.emissiveIntensity;
          }
          if (isSel) {
            obj.material.emissive = obj.material.emissive.clone().lerp(new THREE.Color(0.2, 0.85, 1.4), 0.65);
            obj.material.emissiveIntensity = Math.max(obj.userData.origEmissiveInt, 0.75);
          } else {
            obj.material.emissive.copy(obj.userData.origEmissive);
            obj.material.emissiveIntensity = obj.userData.origEmissiveInt;
          }
        }
      });
    }
  }

  return {
    group: root,
    pickables,
    moduleMap,
    setPixelRatio(pr) {
      particleMat.uniforms.uPR.value = pr;
    },
    setExplode(val) {
      targetExplode = THREE.MathUtils.clamp(val, 0, 1);
    },
    getExplode() {
      return targetExplode;
    },
    selectModule(id) {
      setSelected(id);
    },
    getSelected() {
      return selectedId;
    },
    getModuleWorldCenter(id, out = new THREE.Vector3()) {
      const m = moduleMap[id];
      if (!m) return root.getWorldPosition(out);
      return m.group.getWorldPosition(out);
    },
    update(dt, time) {
      explodeAmount += (targetExplode - explodeAmount) * Math.min(1, dt * 4.2);

      // Animate counterfactual centrifuge rings & reactor gimbals
      moduleMap.ringA.spinTarget.rotation.z += dt * 0.22;
      moduleMap.ringB.spinTarget.rotation.z -= dt * 0.36;
      const gimbals = moduleMap.core.gimbals;
      gimbals[0].rotation.x = time * 0.7;
      gimbals[1].rotation.y = -time * 0.55;
      gimbals[2].rotation.x = time * 0.35;
      gimbals[2].rotation.z = time * 0.45;
      moduleMap.core.coreShell.rotation.y = time * 0.4;
      const pulse = 1 + 0.08 * Math.sin(time * 4.2);
      moduleMap.core.coreOrb.scale.setScalar(pulse);

      // Solar wing subtle sun-tracking oscillation
      const sw = 0.28 * Math.sin(time * 0.15);
      moduleMap.solarPort.wingPivot.rotation.x = sw;
      moduleMap.solarStbd.wingPivot.rotation.x = sw;

      // Exploded view offsets + selected module pull-out emphasis
      let idx = 0;
      const posArr = tetherGeo.attributes.position.array;
      for (const [id, entry] of Object.entries(moduleMap)) {
        const extra = id === selectedId ? 0.32 : 0;
        _targetVec.copy(entry.explodeVec).multiplyScalar(explodeAmount + extra);
        entry.curOffset.lerp(_targetVec, Math.min(1, dt * 6.0));
        entry.group.position.copy(entry.curOffset);

        posArr[idx * 6 + 0] = 0;
        posArr[idx * 6 + 1] = 0;
        posArr[idx * 6 + 2] = 0;
        posArr[idx * 6 + 3] = entry.curOffset.x;
        posArr[idx * 6 + 4] = entry.curOffset.y;
        posArr[idx * 6 + 5] = entry.curOffset.z;
        idx++;
      }
      tetherGeo.attributes.position.needsUpdate = true;
      tetherLines.material.opacity = THREE.MathUtils.clamp(explodeAmount * 0.65, 0, 0.55);

      holoMat.uniforms.uTime.value = time;
      holoMat.uniforms.uAlpha.value = 0.12 + 0.26 * explodeAmount;
      shieldMesh.visible = explodeAmount > 0.02 || selectedId !== null;

      particleMat.uniforms.uTime.value = time;
      particleMat.uniforms.uExplode.value = explodeAmount;

      for (const b of beacons) {
        const { base, period, phase } = b.userData;
        const on = (((time + phase) % period) / period) < 0.12 ? 1.0 : 0.08;
        b.material.color.copy(base).multiplyScalar(on);
      }
    },
  };
}
