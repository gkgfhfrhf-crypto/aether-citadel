import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { BODIES, STATION_MODULES, AU_KM, KM_PER_UNIT, distanceBetweenKm, formatKm } from './data.js';
import {
  makeAtmosphereMaterial, makeRingMaterial, makeDeepStars,
  makeStreaks, makeTunnel, makeDust, PostShader,
} from './shaders.js';
import { createCosmicStation } from './station.js';
import { createStarship } from './ship.js';
import { AudioFX } from './audio.js';

const V3 = THREE.Vector3;
const UP = new V3(0, 1, 0);
const clamp = (x, a, b) => Math.min(b, Math.max(a, x));
const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
const easeOutExpo = (x) => (x >= 1 ? 1 : 1 - Math.pow(2, -10 * x));

const _qs = new URLSearchParams(location.search);
const FIXED_DT = parseFloat(_qs.get('dt')) || 0;
const MANUAL_STEP = _qs.get('manual') === '1';

/* ------------------------------------------------------------------ */
/* WebGL 3D Renderer & Unified Solar System Scene                      */
/* ------------------------------------------------------------------ */
const canvas = document.getElementById('scene');
const IS_TOUCH_DEVICE = matchMedia('(pointer: coarse)').matches || navigator.maxTouchPoints > 0;
const renderer = new THREE.WebGLRenderer({
  canvas, antialias: !IS_TOUCH_DEVICE, logarithmicDepthBuffer: true,
  powerPreference: 'high-performance',
  preserveDrawingBuffer: MANUAL_STEP,
});
// Keep the original assets and effects, but avoid rendering more pixels than a tablet GPU can sustain.
const PR = Math.min(window.devicePixelRatio || 1, IS_TOUCH_DEVICE ? 1.3 : 1.7);
renderer.setPixelRatio(PR);
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.06;

const scene = new THREE.Scene();
// Vast view frustum: 0.15 units (close module details) to 1.5e7 units (entire Solar System)
const camera = new THREE.PerspectiveCamera(48, window.innerWidth / window.innerHeight, 0.15, 1.5e7);
scene.add(camera);

const manager = new THREE.LoadingManager();
const loader = new THREE.TextureLoader(manager);
const maxAniso = Math.min(renderer.capabilities.getMaxAnisotropy(), IS_TOUCH_DEVICE ? 4 : 8);
const allTextures = [];
function tex(name, srgb = true) {
  const t = loader.load('../tex/' + name);
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = maxAniso;
  allTextures.push(t);
  return t;
}
const T = {
  stars: tex('stars.jpg'),
  sun: tex('sun.jpg'),
  mercury: tex('mercury.jpg'),
  venus: tex('venus.jpg'),
  earthDay: tex('earth_day.jpg'),
  earthNight: tex('earth_night.jpg'),
  clouds: tex('earth_clouds.jpg', false),
  earthNormal: tex('earth_normal.jpg', false),
  earthSpec: tex('earth_spec.jpg', false),
  moon: tex('moon.jpg'),
  mars: tex('mars.jpg'),
  jupiter: tex('jupiter.jpg'),
  saturn: tex('saturn.jpg'),
  ring: tex('saturn_ring.png'),
  uranus: tex('uranus.jpg'),
  neptune: tex('neptune.jpg'),
};
T.stars.mapping = THREE.EquirectangularReflectionMapping;
scene.background = T.stars;
scene.backgroundIntensity = 0.5;

// 10,000 Volumetric 3D stars + Milky Way nebula dust
const deepStars = makeDeepStars(10000);
deepStars.material.uniforms.uPR.value = PR;
scene.add(deepStars);

let envMap = null;

/* ------------------------------------------------------------------ */
/* Solar System Lighting (True Sun Direction per Active Location)      */
/* ------------------------------------------------------------------ */
const bodyById = Object.fromEntries(BODIES.map((b) => {
  b.worldPos = new V3(...b.pos);
  return [b.id, b];
}));

const sunWorldPos = bodyById.sun.worldPos;
const sunDir = new V3(-0.88, 0.12, -0.28).normalize();
const sunLight = new THREE.DirectionalLight(0xfff5ea, 3.5);
scene.add(sunLight, sunLight.target);
scene.add(new THREE.HemisphereLight(0x4b749f, 0x0c1220, 0.16));

function radialTexture(stops) {
  const c = document.createElement('canvas');
  c.width = c.height = 256;
  const g = c.getContext('2d');
  const r = g.createRadialGradient(128, 128, 0, 128, 128, 128);
  stops.forEach(([o, col]) => r.addColorStop(o, col));
  g.fillStyle = r;
  g.fillRect(0, 0, 256, 256);
  return new THREE.CanvasTexture(c);
}

/* ------------------------------------------------------------------ */
/* Persistent 3D Solar System Planet & Asteroid Builders               */
/* ------------------------------------------------------------------ */
const sphere = (r, w = 160, h = 80) => new THREE.SphereGeometry(r, w, h);

function atmosphere(R, { color, twilight, intensity = 1, power = 2, thickness = 1.04, front = 0.6 }, localSunDir) {
  const g = new THREE.Group();
  const back = new THREE.Mesh(sphere(R * thickness, 96, 48), makeAtmosphereMaterial({
    color, twilight, intensity, power, k: Math.sqrt(1 - 1 / (thickness * thickness)), front: false, sunDir: localSunDir,
  }));
  g.add(back);
  if (front > 0) {
    const f = new THREE.Mesh(sphere(R * 1.006, 96, 48), makeAtmosphereMaterial({
      color, twilight, intensity: front, power: 1.5, k: 1, front: true, sunDir: localSunDir,
    }));
    g.add(f);
  }
  return g;
}

// Earth 4K Shader: NASA Blue Marble + Ocean Specular + Normal Relief + Black Marble Night City Lights + Drifting Clouds
const earthUniforms = {
  nightMap: { value: T.earthNight },
  cloudMap: { value: T.clouds },
  sunDirView: { value: new V3() },
  cloudOffset: { value: 0 },
  nightBoost: { value: 3.45 },
};
const earthMat = new THREE.MeshPhongMaterial({
  map: T.earthDay,
  specularMap: T.earthSpec,
  specular: new THREE.Color(0x5c7590),
  shininess: 30,
  normalMap: T.earthNormal,
  normalScale: new THREE.Vector2(1.1, 1.1),
});
earthMat.onBeforeCompile = (sh) => {
  Object.assign(sh.uniforms, earthUniforms);
  sh.fragmentShader = sh.fragmentShader
    .replace('#include <common>', `#include <common>
      uniform sampler2D nightMap; uniform sampler2D cloudMap; uniform vec3 sunDirView;
      uniform float cloudOffset; uniform float nightBoost;`)
    .replace('#include <emissivemap_fragment>', `#include <emissivemap_fragment>
      vec3 nGeo = normalize(vNormal);
      float sd = dot(nGeo, sunDirView);
      float nightMask = smoothstep(0.06, -0.15, sd);
      float twilightBand = exp(-pow((sd + 0.01) / 0.08, 2.0));
      float cl = texture2D(cloudMap, vec2(fract(vMapUv.x - cloudOffset), vMapUv.y)).g;
      vec3 city = texture2D(nightMap, vMapUv).rgb;
      city = pow(city, vec3(1.22)) * nightBoost * (1.0 - cl * 0.62);
      totalEmissiveRadiance += city * vec3(1.0, 0.85, 0.56) * nightMask;
      totalEmissiveRadiance += vec3(0.96, 0.44, 0.16) * twilightBand * 0.035;
      diffuseColor.rgb *= 1.0 - cl * 0.34;
      vec3 vdir = normalize(vViewPosition);
      float fres = pow(1.0 - max(dot(nGeo, vdir), 0.0), 3.0);
      totalEmissiveRadiance += vec3(0.26, 0.56, 1.0) * fres * smoothstep(-0.18, 0.52, sd) * 0.58;`);
};
const cloudMat = new THREE.MeshLambertMaterial({
  color: 0xffffff, alphaMap: T.clouds, transparent: true, depthWrite: false, opacity: 0.92,
});

function makeRocky(R, map, { bump = 0, roughness = 0.95, scaleY = 1, atmo = null, tint = 0xffffff, rotate = 0.003, segs = 160 } = {}, pSunDir = sunDir) {
  const group = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ map, color: tint, roughness, metalness: 0 });
  if (bump) { mat.bumpMap = map; mat.bumpScale = bump; }
  const mesh = new THREE.Mesh(sphere(R, segs, segs / 2), mat);
  mesh.scale.y = scaleY;
  group.add(mesh);
  if (atmo) {
    const a = atmosphere(R, atmo, pSunDir);
    a.scale.y = scaleY;
    group.add(a);
  }
  return { group, mesh, update(dt) { mesh.rotation.y += dt * rotate; } };
}

function createAsteroidBelt() {
  const count = 900;
  const geo = new THREE.DodecahedronGeometry(1, 1);
  const mat = new THREE.MeshStandardMaterial({ map: T.mercury, color: 0x9b9288, roughness: 0.94, metalness: 0.08 });
  const inst = new THREE.InstancedMesh(geo, mat, count);
  inst.frustumCulled = false;
  const dummy = new THREE.Object3D();
  // Cluster belts near Mars->Jupiter corridor and a sparse scenic asteroid cluster near the Moon/Earth sector
  for (let i = 0; i < count; i++) {
    if (i < 160) {
      // Scenic outer-Earth / Lunar debris field for thrilling 3rd-person fly-through
      const ang = Math.random() * Math.PI * 2;
      const rad = 620 + Math.random() * 1450;
      dummy.position.set(
        Math.cos(ang) * rad + 280,
        (Math.random() - 0.5) * 320,
        Math.sin(ang) * rad - 350
      );
      dummy.scale.set(
        2.2 + Math.random() * 7.5,
        1.6 + Math.random() * 5.5,
        2.0 + Math.random() * 6.8
      );
    } else {
      // Main belt between Mars and Jupiter
      const t = Math.random();
      dummy.position.set(
        34000 + t * 24000 + (Math.random() - 0.5) * 14000,
        (Math.random() - 0.5) * 6500,
        -34000 - t * 20000 + (Math.random() - 0.5) * 14000
      );
      const s = 18 + Math.pow(Math.random(), 2.2) * 95;
      dummy.scale.set(s * 1.2, s * 0.85, s);
    }
    dummy.rotation.set(Math.random() * 6, Math.random() * 6, Math.random() * 6);
    dummy.updateMatrix();
    inst.setMatrixAt(i, dummy.matrix);
  }
  scene.add(inst);
  return inst;
}

const updatables = [];
let station = null;
let ship = null;
let saturnRingMat = null;

function buildSolarSystem() {
  // 1. THE SUN (Glowing star + giant corona sprites)
  {
    const b = bodyById.sun;
    const g = new THREE.Group();
    g.position.copy(b.worldPos);
    const sunMesh = new THREE.Mesh(
      sphere(b.radius, 128, 64),
      new THREE.MeshBasicMaterial({ map: T.sun, color: new THREE.Color(2.6, 2.1, 1.5) })
    );
    g.add(sunMesh);

    const corona = new THREE.Sprite(new THREE.SpriteMaterial({
      map: radialTexture([
        [0, 'rgba(255,255,255,1)'], [0.14, 'rgba(255,235,195,0.85)'],
        [0.34, 'rgba(255,175,90,0.28)'], [0.7, 'rgba(255,110,35,0.05)'], [1, 'rgba(0,0,0,0)'],
      ]),
      color: new THREE.Color(2.8, 2.2, 1.6), blending: THREE.AdditiveBlending, depthWrite: false, transparent: true,
    }));
    corona.scale.setScalar(b.radius * 9.5);
    g.add(corona);
    scene.add(g);
    updatables.push((dt) => { sunMesh.rotation.y += dt * 0.002; });
  }

  // 2. EARTH (Origin [0,0,0], Radius 180)
  {
    const b = bodyById.earth;
    const g = new THREE.Group();
    g.position.copy(b.worldPos);
    const tilt = new THREE.Group();
    tilt.rotation.z = THREE.MathUtils.degToRad(16);
    const mesh = new THREE.Mesh(sphere(b.radius, 256, 128), earthMat);
    mesh.rotation.y = -0.95; // Orient Asia/Europe terminator toward station & camera so glowing night cities & blue oceans both shine
    const clouds = new THREE.Mesh(sphere(b.radius * 1.008, 192, 96), cloudMat);
    mesh.add(clouds);
    tilt.add(mesh);
    g.add(tilt);
    g.add(atmosphere(b.radius, {
      color: [0.28, 0.58, 1.0], twilight: [1.0, 0.42, 0.16],
      intensity: 1.8, power: 2.2, thickness: 1.046, front: 0.78,
    }, sunDir));
    scene.add(g);
    updatables.push((dt) => {
      mesh.rotation.y += dt * 0.0038;
      clouds.rotation.y += dt * 0.0011;
      earthUniforms.cloudOffset.value = clouds.rotation.y / (Math.PI * 2);
    });
  }

  // 3. AETHER CITADEL — Cosmic 3D Space Station in High Earth Orbit
  {
    const b = bodyById.station;
    station = createCosmicStation(envMap);
    station.setPixelRatio(PR);
    station.group.position.copy(b.worldPos);
    station.group.rotation.set(0.18, -0.42, 0.08);
    scene.add(station.group);
    updatables.push((dt, time) => station.update(dt, time));
  }

  // 4. MOON
  {
    const b = bodyById.moon;
    const p = makeRocky(b.radius, T.moon, { bump: 1.6, rotate: 0.0015, segs: 192 });
    p.group.position.copy(b.worldPos);
    scene.add(p.group);
    updatables.push((dt) => p.update(dt));
  }

  // 5. MERCURY
  {
    const b = bodyById.mercury;
    const p = makeRocky(b.radius, T.mercury, { bump: 1.3, rotate: 0.002, segs: 160 });
    p.group.position.copy(b.worldPos);
    scene.add(p.group);
    updatables.push((dt) => p.update(dt));
  }

  // 6. VENUS
  {
    const b = bodyById.venus;
    const p = makeRocky(b.radius, T.venus, {
      roughness: 0.85, rotate: -0.0018, segs: 192,
      atmo: { color: [1.0, 0.86, 0.58], twilight: [0.95, 0.55, 0.22], intensity: 1.25, power: 2.1, thickness: 1.045, front: 0.65 },
    });
    p.group.position.copy(b.worldPos);
    scene.add(p.group);
    updatables.push((dt) => p.update(dt));
  }

  // 7. MARS
  {
    const b = bodyById.mars;
    const p = makeRocky(b.radius, T.mars, {
      bump: 1.2, rotate: 0.004, segs: 224,
      atmo: { color: [0.95, 0.68, 0.5], twilight: [0.58, 0.46, 0.92], intensity: 0.78, power: 2.5, thickness: 1.028, front: 0.38 },
    });
    p.group.position.copy(b.worldPos);
    p.group.rotation.z = THREE.MathUtils.degToRad(25);
    scene.add(p.group);
    updatables.push((dt) => p.update(dt));
  }

  // 8. JUPITER + IO
  {
    const b = bodyById.jupiter;
    const g = new THREE.Group();
    g.position.copy(b.worldPos);
    const jup = makeRocky(b.radius, T.jupiter, {
      rotate: 0.006, roughness: 0.88, scaleY: 0.935, segs: 256,
      atmo: { color: [0.92, 0.82, 0.68], twilight: [0.92, 0.54, 0.3], intensity: 0.52, power: 2.5, thickness: 1.018, front: 0.36 },
    });
    g.add(jup.group);
    const io = makeRocky(42, T.moon, { tint: 0xf2cf74, bump: 1.0, rotate: 0.003 });
    io.group.position.set(-b.radius * 1.65, b.radius * 0.22, b.radius * 1.45);
    g.add(io.group);
    scene.add(g);
    updatables.push((dt) => { jup.update(dt); io.update(dt); });
  }

  // 9. SATURN + 8K RADIAL RINGS + TITAN
  {
    const b = bodyById.saturn, R = b.radius;
    const g = new THREE.Group();
    g.position.copy(b.worldPos);
    const tilt = new THREE.Group();
    tilt.rotation.z = THREE.MathUtils.degToRad(-16);
    tilt.rotation.x = THREE.MathUtils.degToRad(11);
    const sat = makeRocky(R, T.saturn, {
      rotate: 0.0052, roughness: 0.9, scaleY: 0.902, segs: 256,
      atmo: { color: [0.95, 0.86, 0.66], twilight: [0.9, 0.6, 0.35], intensity: 0.45, power: 2.6, thickness: 1.016, front: 0.3 },
    });
    tilt.add(sat.group);

    const inner = R * 1.23, outer = R * 2.35;
    const rg = new THREE.RingGeometry(inner, outer, 512, 1);
    const pos = rg.attributes.position, uv = rg.attributes.uv, v = new V3();
    for (let i = 0; i < pos.count; i++) {
      v.fromBufferAttribute(pos, i);
      uv.setXY(i, (v.length() - inner) / (outer - inner), 0.5);
    }
    saturnRingMat = makeRingMaterial(T.ring, sunDir, R * 0.96);
    saturnRingMat.uniforms.uCenter.value.copy(b.worldPos);
    const ring = new THREE.Mesh(rg, saturnRingMat);
    ring.rotation.x = -Math.PI / 2;
    tilt.add(ring);
    g.add(tilt);

    const titan = makeRocky(54, T.moon, {
      tint: 0xe6b66e, roughness: 0.95, rotate: 0.001,
      atmo: { color: [0.95, 0.7, 0.32], twilight: [0.85, 0.48, 0.2], intensity: 0.95, power: 2.2, thickness: 1.06, front: 0.55 },
    });
    titan.group.position.set(-R * 2.9, R * 1.35, -R * 2.4);
    g.add(titan.group);
    scene.add(g);
    updatables.push((dt) => { sat.update(dt); titan.update(dt); });
  }

  // 10. URANUS + VERTICAL FAINT RING
  {
    const b = bodyById.uranus, R = b.radius;
    const g = new THREE.Group();
    g.position.copy(b.worldPos);
    const tilt = new THREE.Group();
    tilt.rotation.z = THREE.MathUtils.degToRad(82);
    const ura = makeRocky(R, T.uranus, {
      rotate: 0.0048, roughness: 0.86, segs: 192,
      atmo: { color: [0.48, 0.88, 0.96], twilight: [0.35, 0.65, 0.95], intensity: 1.25, power: 2.1, thickness: 1.035, front: 0.62 },
    });
    tilt.add(ura.group);
    const uRing = new THREE.Mesh(
      new THREE.RingGeometry(R * 1.45, R * 1.68, 192),
      new THREE.MeshBasicMaterial({ color: 0x8fd6e8, transparent: true, opacity: 0.22, side: THREE.DoubleSide, depthWrite: false })
    );
    uRing.rotation.x = -Math.PI / 2;
    tilt.add(uRing);
    g.add(tilt);
    scene.add(g);
    updatables.push((dt) => ura.update(dt));
  }

  // 11. NEPTUNE
  {
    const b = bodyById.neptune;
    const p = makeRocky(b.radius, T.neptune, {
      rotate: 0.0054, roughness: 0.86, segs: 192,
      atmo: { color: [0.3, 0.56, 1.0], twilight: [0.48, 0.4, 1.0], intensity: 1.55, power: 2.0, thickness: 1.038, front: 0.72 },
    });
    p.group.position.copy(b.worldPos);
    p.group.rotation.z = THREE.MathUtils.degToRad(28);
    scene.add(p.group);
    updatables.push((dt) => p.update(dt));
  }

  // 12. Asteroid Fields + 3rd-Person Player Starship
  createAsteroidBelt();

  ship = createStarship(envMap);
  ship.setPixelRatio(PR);
  // Park starship near the Cosmic Station overlooking Earth
  ship.group.position.set(-215, 112, 462);
  ship.group.lookAt(bodyById.station.worldPos);
  ship.resetTrail(ship.group.position);
  scene.add(ship.group);
  scene.add(ship.trailPoints);
}

/* ------------------------------------------------------------------ */
/* Warp FX & Optical Post-Processing                                   */
/* ------------------------------------------------------------------ */
const STREAK_LEN = 1650;
const streaks = makeStreaks(6000, STREAK_LEN);
const tunnel = makeTunnel(48, 1900);
camera.add(tunnel, streaks);

const dust = makeDust(1600);
dust.material.uniforms.uPR.value = PR;
scene.add(dust);

const composer = new EffectComposer(renderer);
composer.setPixelRatio(PR);
composer.setSize(window.innerWidth, window.innerHeight);
composer.addPass(new RenderPass(scene, camera));
const bloom = new UnrealBloomPass(new THREE.Vector2(window.innerWidth * 0.78, window.innerHeight * 0.78), 0.52, 0.55, 0.88);
composer.addPass(bloom);
bloom.setSize(window.innerWidth * 0.78, window.innerHeight * 0.78);
const post = new ShaderPass(PostShader);
post.uniforms.uRes.value.set(window.innerWidth * PR, window.innerHeight * PR);
composer.addPass(post);
composer.addPass(new OutputPass());

/* ------------------------------------------------------------------ */
/* 3-Mode State: 'panorama' | 'architect' | 'flight'                   */
/* ------------------------------------------------------------------ */
const audio = new AudioFX();
let started = false;
let mode = 'panorama'; // 'panorama' | 'architect' | 'flight'

const orbit = {
  body: bodyById.station,
  center: new V3().copy(bodyById.station.worldPos),
  targetCenter: new V3().copy(bodyById.station.worldPos),
  yaw: -0.52,
  pitch: 0.16,
  targetYaw: -0.52,
  targetPitch: 0.16,
  dist: 148,       // Panorama default: observe station from afar with giant Earth & glowing cities right behind it!
  targetDist: 148,
  approach: 1,
  approachDur: 9,
  startDist: 148,
};

// 3rd-Person Starship Physics State
const flight = {
  vel: new V3(),
  yawRate: 0,
  pitchRate: 0,
  rollRate: 0,
  throttle: 0,
  camPos: new V3(),
  camQuat: new THREE.Quaternion(),
  inited: false,
};
const keys = {};

const pointer = { x: 0, y: 0, down: false, moved: false, lastX: 0, lastY: 0, downX: 0, downY: 0 };
const raycaster = new THREE.Raycaster();
const ndcMouse = new THREE.Vector2();

const CHARGE = 3.2;
let warp = { active: false };
let travel = 0;

const fx = {
  streakI: 0, stretch: 0, speed: 0, tunnelA: 0, fov: 48, shake: 0, ca: 0.05, blur: 0,
  glow: 0, flash: 0, shock: 0, shockAmp: 0, anam: 0, bg: 0.5, bloom: 0.52,
};

function idealOrbitDist(b, m = mode) {
  if (b.id === 'station') {
    return m === 'architect' ? 56 : 158; // Architect: close 3D inspection; Panorama: grand distant orbital vista with Earth behind!
  }
  const aspectBoost = Math.max(1, 1.3 / camera.aspect);
  if (b.id === 'saturn') return b.radius * 4.3 * aspectBoost;
  if (b.id === 'sun') return b.radius * 3.8 * aspectBoost;
  return b.radius * 3.25 * aspectBoost;
}

/* ------------------------------------------------------------------ */
/* UI Elements & Mode Switching                                        */
/* ------------------------------------------------------------------ */
const $ = (id) => document.getElementById(id);
const ui = {
  name: $('body-name'), en: $('body-en'), desc: $('body-desc'), stats: $('body-stats'),
  status: $('t-status'), speed: $('t-speed'), dist: $('t-dist'), hint: $('control-hint'),
  nav: $('destinations'), archPanel: $('architect-panel'),
  explodeBtn: $('explode-toggle'), explodeRange: $('explode-range'), explodeVal: $('explode-val'),
  modTitle: $('mod-title'), modSpec: $('mod-spec'), modList: $('mod-list'),
  flightReticle: $('flight-reticle'), flightKeys: $('flight-keys'),
  wPhase: $('warp-phase'), wTarget: $('warp-target'), wSpeed: $('warp-speed'), wBar: $('warp-bar'), wDist: $('warp-dist'),
  markersRoot: $('world-markers'),
};

function setMode(nextMode) {
  if (warp.active) return;
  mode = nextMode;
  document.body.classList.toggle('architect-mode', mode === 'architect');
  document.body.classList.toggle('flight-mode', mode === 'flight');

  document.querySelectorAll('.mode-btn').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.mode === mode);
  });

  ui.archPanel.classList.toggle('hidden', mode !== 'architect');
  ui.flightReticle.classList.toggle('hidden', mode !== 'flight');
  ui.flightKeys.classList.toggle('hidden', mode !== 'flight');

  if (mode === 'architect') {
    // Focus directly on the Cosmic Station for interactive 3D module inspection & disassembly
    orbit.body = bodyById.station;
    orbit.targetCenter.copy(bodyById.station.worldPos);
    orbit.targetDist = 56;
    orbit.targetYaw = 0.42;
    orbit.targetPitch = 0.2;
    updateInfo(bodyById.station);
    updateNav();
    ui.hint.textContent = '点击空间站任意 3D 舱段独立高亮检视 · 拖动右侧滑杆无极爆炸拆解';
  } else if (mode === 'panorama') {
    station.selectModule(null);
    updateModuleUI(null);
    orbit.targetCenter.copy(orbit.body.worldPos);
    orbit.targetDist = idealOrbitDist(orbit.body, 'panorama');
    if (orbit.body.id === 'station') {
      orbit.targetYaw = -0.52;
      orbit.targetPitch = 0.16;
    }
    ui.hint.textContent = '拖拽 360° 环绕星域 · 滚轮无极推拉远近（可拉远纵览空间站与地球同框）';
  } else if (mode === 'flight') {
    station.selectModule(null);
    const curB = orbit.body;
    if (curB.id === 'station') {
      // Spawn behind the Cosmic Station so nose (-Z) points straight through the station toward giant Earth!
      const dirFromEarth = curB.worldPos.clone().sub(bodyById.earth.worldPos).normalize();
      ship.group.position.copy(curB.worldPos).addScaledVector(dirFromEarth, 78).add(new V3(-14, 10, 0));
      const awayTarget = ship.group.position.clone().multiplyScalar(2).sub(curB.worldPos);
      ship.group.lookAt(awayTarget);
      ship.resetTrail(ship.group.position);
    } else {
      const desiredStart = curB.worldPos.clone().add(new V3(curB.radius * 0.4, curB.radius * 0.25, curB.radius * 2.6 + 52));
      if (!flight.inited || ship.group.position.distanceTo(curB.worldPos) > curB.radius * 18 + 2000) {
        ship.group.position.copy(desiredStart);
        const awayTarget = ship.group.position.clone().multiplyScalar(2).sub(curB.worldPos);
        ship.group.lookAt(awayTarget);
        ship.resetTrail(ship.group.position);
      }
    }
    flight.vel.set(0, 0, 0);
    const fwd = new V3(0, 0, -1).applyQuaternion(ship.group.quaternion);
    flight.camPos.copy(ship.group.position).addScaledVector(fwd, -13).add(new V3(0, 3.5, 0));
    flight.camQuat.copy(ship.group.quaternion);
    flight.inited = true;
    ui.hint.textContent = 'WASD 推进转向 · Shift 等离子冲刺 · 鼠标拖拽瞄准 · 点击底部星球曲速跃迁';
  }
}

function updateInfo(b) {
  ui.name.textContent = b.name;
  ui.en.textContent = b.en;
  ui.desc.textContent = b.desc;
  ui.stats.innerHTML = b.stats.map(([k, v]) => `<div><dt>${k}</dt><dd>${v}</dd></div>`).join('');
}

function buildArchitectUI() {
  ui.modList.innerHTML = STATION_MODULES.map((m) => `
    <button class="mod-item" data-mod="${m.id}">
      <strong>${m.name}</strong>
      <small>${m.en.split(' ')[0]} · ${m.role.slice(0, 8)}</small>
    </button>
  `).join('');

  ui.modList.addEventListener('click', (e) => {
    const btn = e.target.closest('.mod-item');
    if (!btn) return;
    const id = btn.dataset.mod;
    const next = station.getSelected() === id ? null : id;
    focusStationModule(next);
  });

  ui.explodeRange.addEventListener('input', (e) => {
    const v = Number(e.target.value) / 100;
    station.setExplode(v);
    syncExplodeControls(v);
  });

  ui.explodeBtn.addEventListener('click', () => {
    const next = station.getExplode() > 0.5 ? 0 : 1;
    station.setExplode(next);
    syncExplodeControls(next);
  });
}

function syncExplodeControls(v) {
  const pct = Math.round(v * 100);
  ui.explodeRange.value = String(pct);
  ui.explodeVal.textContent = pct + '%';
  ui.explodeBtn.classList.toggle('active', v > 0.5);
  ui.explodeBtn.textContent = v > 0.5 ? '一键归位合拢' : '一键完全拆解';
}

function updateModuleUI(modId) {
  document.querySelectorAll('.mod-item').forEach((el) => {
    el.classList.toggle('active', el.dataset.mod === modId);
  });
  if (!modId) {
    ui.modTitle.textContent = '全站总成视图 · 8 大模组在线';
    ui.modSpec.textContent = '点击 3D 空间站任意部件或下方按钮，可单独抽离高亮并聚焦查看工程参数。';
    return;
  }
  const meta = STATION_MODULES.find((m) => m.id === modId);
  if (meta) {
    ui.modTitle.textContent = `${meta.name} (${meta.en})`;
    ui.modSpec.textContent = `${meta.role} — ${meta.spec}`;
  }
}

function focusStationModule(modId) {
  station.selectModule(modId);
  updateModuleUI(modId);
  if (!modId) {
    orbit.targetCenter.copy(bodyById.station.worldPos);
    orbit.targetDist = 56;
  } else {
    // Ensure partial explode so internal modules are clearly separated
    if (station.getExplode() < 0.35) {
      station.setExplode(0.45);
      syncExplodeControls(0.45);
    }
    const base = bodyById.station.worldPos;
    const meta = STATION_MODULES.find((m) => m.id === modId);
    const off = new V3(...meta.explode).multiplyScalar(station.getExplode() + 0.32);
    off.applyEuler(station.group.rotation);
    orbit.targetCenter.copy(base).add(off);
    orbit.targetDist = 28;
  }
}

function buildNav() {
  ui.nav.innerHTML = BODIES.map((b) => `
    <button class="dest" id="dest-${b.id}" data-id="${b.id}">
      <span class="orb" style="background:${b.orb}"></span>
      <span>${b.id === 'station' ? '空间站' : b.name}</span>
      <span class="d"></span>
    </button>
  `).join('');
  ui.nav.addEventListener('click', (e) => {
    const btn = e.target.closest('.dest');
    if (!btn) return;
    const target = bodyById[btn.dataset.id];
    triggerTravelTo(target);
  });
}

function updateNav() {
  const ref = orbit.body;
  BODIES.forEach((b) => {
    const el = $('dest-' + b.id);
    if (!el) return;
    const cur = b === ref;
    el.classList.toggle('current', cur);
    el.querySelector('.d').textContent = cur ? '当前' : formatKm(distanceBetweenKm(ref, b));
  });
}

/* 3D World Floating Beacons for Solar System Bodies & Cosmic Station */
const markerEls = {};
function buildWorldMarkers() {
  ui.markersRoot.innerHTML = BODIES.map((b) => `
    <div class="w-marker ${b.id === 'station' ? 'station' : ''}" id="wm-${b.id}" data-id="${b.id}">
      <i></i>
      <span>${b.id === 'station' ? '苍穹堡垒 · 空间站' : b.name}<small></small></span>
    </div>
  `).join('');
  BODIES.forEach((b) => { markerEls[b.id] = $('wm-' + b.id); });
  ui.markersRoot.addEventListener('click', (e) => {
    const m = e.target.closest('.w-marker');
    if (!m) return;
    const target = bodyById[m.dataset.id];
    if (target.id === 'station' && orbit.body.id === 'earth') {
      setMode('architect');
    } else {
      triggerTravelTo(target);
    }
  });
}

const _proj = new V3();
function updateWorldMarkers() {
  if (warp.active) return;
  const w = window.innerWidth, h = window.innerHeight;
  for (const b of BODIES) {
    const el = markerEls[b.id];
    const dScene = camera.position.distanceTo(b.worldPos);
    // Hide marker for the body we are right next to (unless we zoomed far out from station)
    const tooClose = (mode !== 'flight' && b === orbit.body && dScene < b.radius * 8 + 120) ||
                     (dScene < b.radius * 3.8);
    if (tooClose) {
      el.style.transform = 'translate3d(-9999px,-9999px,0)';
      continue;
    }
    _proj.copy(b.worldPos).project(camera);
    if (_proj.z >= 1 || Math.abs(_proj.x) > 0.94 || Math.abs(_proj.y) > 0.88) {
      el.style.transform = 'translate3d(-9999px,-9999px,0)';
      continue;
    }
    const sx = (_proj.x * 0.5 + 0.5) * w;
    const sy = (-_proj.y * 0.5 + 0.5) * h;
    el.style.transform = `translate3d(${(sx - 6).toFixed(1)}px, ${(sy - 8).toFixed(1)}px, 0)`;
    const km = dScene * KM_PER_UNIT;
    el.querySelector('small').textContent = formatKm(km);
  }
}

/* ------------------------------------------------------------------ */
/* Travel / Cinematic Hyperspace Quantum Warp                          */
/* ------------------------------------------------------------------ */
function triggerTravelTo(to) {
  if (!started || warp.active || !to) return;
  if (to === orbit.body && mode !== 'flight') {
    if (to.id === 'station') {
      orbit.targetCenter.copy(to.worldPos);
      orbit.targetDist = idealOrbitDist(to, mode);
    }
    return;
  }
  // Short local hop between Station <-> Earth uses smooth sub-light glide if in panorama/architect
  const pair = [orbit.body.id, to.id].sort().join('-');
  if (pair === 'earth-station' && mode !== 'flight') {
    arriveAtBody(to, 2.2, 2.6);
    return;
  }

  const km = distanceBetweenKm(orbit.body, to);
  const au = km / AU_KM;
  warp = {
    active: true,
    t: 0,
    from: orbit.body,
    to,
    km,
    tunnelDur: 6.2 + 2.4 * Math.log10(1 + au * 9),
    jumped: false,
    teleported: false,
    hudBack: false,
  };
  document.body.classList.add('warping');
  ui.wTarget.textContent = `目标星域 · ${to.name}`;
  ui.wDist.textContent = formatKm(km);
  audio.charge(CHARGE);

  // Align starship nose (-Z) toward destination if in 3rd-person flight mode
  if (mode === 'flight') {
    ship.group.lookAt(ship.group.position.clone().multiplyScalar(2).sub(to.worldPos));
  }
}

function arriveAtBody(body, fromMult = 24, dur = 9.5) {
  orbit.body = body;
  orbit.targetCenter.copy(body.worldPos);
  orbit.center.copy(body.worldPos);

  // Orient sun light realistically from the Sun toward this body (with gentle artistic angle on Earth so city lights shine!)
  if (body.id === 'earth' || body.id === 'station') {
    sunDir.set(-0.88, 0.14, -0.12).normalize();
  } else if (body.id === 'sun') {
    sunDir.set(0, 0.2, 1).normalize();
  } else {
    sunDir.copy(sunWorldPos).sub(body.worldPos).normalize();
  }
  if (saturnRingMat) saturnRingMat.uniforms.uCenter.value.copy(bodyById.saturn.worldPos);

  const ideal = idealOrbitDist(body, mode === 'architect' && body.id === 'station' ? 'architect' : 'panorama');
  orbit.targetDist = ideal;
  orbit.startDist = ideal * fromMult;
  orbit.dist = orbit.startDist;
  orbit.approach = fromMult > 1.05 ? 0 : 1;
  orbit.approachDur = dur;

  if (body.id === 'station') {
    orbit.yaw = orbit.targetYaw = -0.52;
    orbit.pitch = orbit.targetPitch = 0.16;
  } else {
    // Frame lit terminator hemisphere nicely
    const toSunYaw = Math.atan2(sunDir.x, sunDir.z);
    orbit.yaw = orbit.targetYaw = toSunYaw + 1.15;
    orbit.pitch = orbit.targetPitch = body.id === 'saturn' ? 0.34 : 0.14;
  }

  // Place player starship right in the arrival corridor facing (-Z nose) straight at the body!
  const arrivalDir = new V3(Math.sin(orbit.yaw), Math.sin(orbit.pitch), Math.cos(orbit.yaw)).normalize();
  const shipStopDist = body.id === 'station' ? 78 : body.radius * 2.5 + 45;
  ship.group.position.copy(body.worldPos).addScaledVector(arrivalDir, shipStopDist);
  ship.group.lookAt(ship.group.position.clone().multiplyScalar(2).sub(body.worldPos));
  ship.resetTrail(ship.group.position);
  flight.vel.copy(arrivalDir).multiplyScalar(-body.radius * 0.15);
  flight.camPos.copy(ship.group.position).addScaledVector(arrivalDir, 15);
  flight.inited = true;

  dust.material.uniforms.uBox.value = clamp(body.radius * 0.85, 55, 420);
  updateInfo(body);
  updateNav();
}

function surge(p) { return Math.exp(-Math.pow((p - 0.56) / 0.075, 2)); }

function updateWarp(dt) {
  const baseFov = mode === 'flight' ? 54 : 48;
  const tgt = {
    streakI: 0, stretch: 0, speed: 0, tunnelA: 0, fov: baseFov, shake: 0,
    ca: 0.04, blur: 0, glow: 0, flash: 0, shock: 0, shockAmp: 0, anam: 0, bg: 0.5, bloom: 0.52,
  };
  if (!warp.active) {
    Object.keys(tgt).forEach((k) => { fx[k] += (tgt[k] - fx[k]) * Math.min(1, dt * 2.8); });
    return;
  }

  warp.t += dt;
  const t = warp.t, C = CHARGE, E = C + warp.tunnelDur;
  let phase, progress;

  if (t < C) {
    const p = t / C, e = p * p;
    phase = '曲速引擎蓄能 · 空间曲率折叠';
    progress = 0;
    Object.assign(fx, {
      streakI: e * 0.9, stretch: e * e * 22, speed: 12 + e * e * 360, tunnelA: 0,
      fov: baseFov - 8 * smooth(0, 1, p), shake: e * 0.6, ca: 0.05 + e * 0.55, blur: e * 0.18,
      glow: e * 1.4, flash: 0, shockAmp: 0, anam: e * 0.88, bg: 0.5 * (1 - e * 0.4), bloom: 0.52 + e * 0.55,
    });
  } else if (t < E) {
    const k = t - C, p = k / warp.tunnelDur;
    if (!warp.jumped) { warp.jumped = true; audio.boom(1); audio.tunnel(warp.tunnelDur); }
    const jin = 1 - Math.exp(-k * 5);
    const s = surge(p);
    phase = s > 0.38 ? '空间褶皱二段跃升 · 超光速巡航' : '超空间虫洞穿梭中';
    progress = p;
    Object.assign(fx, {
      streakI: 1, stretch: 20 + 320 * jin * (1 + 0.55 * s), speed: 360 + 2800 * jin * (1 + 0.72 * s),
      tunnelA: smooth(0, 0.65, k) * (1 - smooth(warp.tunnelDur - 0.36, warp.tunnelDur, k)) * (0.9 + 0.3 * s),
      fov: 40 + 62 * easeOutExpo(Math.min(k / 0.55, 1)) + 3 * Math.sin(k * 1.4) + 6.5 * s,
      shake: 1.15 * Math.exp(-k * 2.2) + 0.24 + 0.56 * s, ca: 0.58 + 1.25 * Math.exp(-k * 2.5) + 0.52 * s,
      blur: 0.38 + 0.62 * Math.exp(-k * 2) + 0.32 * s, glow: 0.75 + 0.25 * Math.sin(k * 2.1) + 0.65 * s,
      flash: Math.exp(-k * 6.2), shock: k * 1.5, shockAmp: Math.max(0, 1 - k / 0.9),
      anam: 0.55 + 0.42 * s, bg: 0.02, bloom: 1.05 + 0.5 * s,
    });
  } else {
    const k = t - E;
    if (!warp.teleported) {
      warp.teleported = true;
      if (mode === 'architect' && warp.to.id !== 'station') setMode('panorama');
      arriveAtBody(warp.to, 26, 10.5);
      audio.arrive();
    }
    if (!warp.hudBack && k > 1.3) { warp.hudBack = true; document.body.classList.remove('warping'); }
    phase = '脱离超空间 · 引力圈减速捕获';
    progress = 1;
    Object.assign(fx, {
      streakI: Math.exp(-k * 1.5), stretch: 340 * Math.exp(-k * 3.5), speed: 3100 * Math.exp(-k * 2.2),
      tunnelA: 0, fov: baseFov + 55 * Math.exp(-k * 4.5), shake: 1.35 * Math.exp(-k * 2.6),
      ca: 0.05 + 1.35 * Math.exp(-k * 2.2), blur: 0.92 * Math.exp(-k * 3.5), glow: 1.25 * Math.exp(-k * 4),
      flash: 0.95 * Math.exp(-k * 4.5), shock: k * 1.6, shockAmp: Math.max(0, 1 - k / 0.9),
      anam: 0.62 * Math.exp(-k * 3), bg: 0.5 * (1 - Math.exp(-k * 2.5)), bloom: 0.52 + 0.62 * Math.exp(-k * 2),
    });
    if (k > 4.2) { warp.active = false; travel = 0; }
  }

  ui.wPhase.textContent = phase;
  ui.wSpeed.textContent = Math.round(fx.speed * 4.4).toLocaleString('en-US');
  ui.wBar.style.width = (progress * 100).toFixed(1) + '%';
  ui.wDist.textContent = progress < 1 ? '剩余航程 ' + formatKm(warp.km * (1 - progress)) : '已抵达 ' + warp.to.name;
}

/* ------------------------------------------------------------------ */
/* Camera & 3rd-Person Starship Flight Simulation                      */
/* ------------------------------------------------------------------ */
const _camOffset = new V3(), _fwd = new V3(), _right = new V3(), _up = new V3(), _look = new V3();
const _shipFwd = new V3(), _shipRight = new V3(), _shipUp = new V3();

function updateOrbitCamera(dt, time) {
  orbit.center.lerp(orbit.targetCenter, Math.min(1, dt * 5.0));
  orbit.yaw += (orbit.targetYaw - orbit.yaw) * Math.min(1, dt * 6.0);
  orbit.pitch += (orbit.targetPitch - orbit.pitch) * Math.min(1, dt * 6.0);

  if (orbit.approach < 1) {
    orbit.approach = Math.min(1, orbit.approach + dt / orbit.approachDur);
    const e = 1 - Math.pow(1 - orbit.approach, 3);
    orbit.dist = orbit.startDist + (orbit.targetDist - orbit.startDist) * e;
  } else {
    orbit.dist += (orbit.targetDist - orbit.dist) * Math.min(1, dt * 6.0);
  }

  // Stable orbit camera: no time-based idle drift. Camera moves only from explicit user input or scripted transitions.
  const y = orbit.yaw;
  const p = orbit.pitch;
  const cp = Math.cos(p);

  _camOffset.set(Math.sin(y) * cp, Math.sin(p), Math.cos(y) * cp).multiplyScalar(orbit.dist);
  camera.position.copy(orbit.center).add(_camOffset);

  // Subtle cinematic framing offset in Panorama mode so planet/station sits slightly right of left text panel
  _fwd.copy(_camOffset).negate().normalize();
  _right.crossVectors(_fwd, UP).normalize();
  _up.crossVectors(_right, _fwd).normalize();

  const panShift = mode === 'panorama' ? -orbit.dist * 0.11 * smooth(0.8, 1.4, camera.aspect) : 0;
  _look.copy(orbit.center).addScaledVector(_right, panShift);
  camera.lookAt(_look);

  // Keep the parked starship fixed in panorama/architect modes. Its visual model and engine FX remain intact.
  if (!warp.active) {
    ship.update(dt, time, 0.35, false, 0, 0);
  }

  // Telemetry
  const b = orbit.body;
  const surfKm = Math.max(0, camera.position.distanceTo(b.worldPos) - b.radius) * KM_PER_UNIT;
  ui.dist.textContent = formatKm(surfKm);
  ui.speed.textContent = mode === 'architect' ? '相对静止 (伴飞)' : '7.68 km/s 环绕';
  ui.status.textContent = mode === 'architect' ? '空间站拆解检视' : (orbit.approach < 0.99 ? '曲速脱离入轨' : '深空全景鸟瞰');
}

function updateFlightMode(dt, time) {
  const boost = Boolean(keys.ShiftLeft || keys.ShiftRight);
  const thrustFwd = (keys.KeyW || keys.ArrowUp ? 1 : 0) - (keys.KeyS || keys.ArrowDown ? 0.6 : 0);
  const strafeYaw = (keys.KeyA || keys.ArrowLeft ? 1 : 0) - (keys.KeyD || keys.ArrowRight ? 1 : 0);
  const liftUp = (keys.KeyE || keys.Space ? 1 : 0) - (keys.KeyQ || keys.ControlLeft ? 1 : 0);

  // Adaptive speed scale: fast in deep interplanetary space, precise near station & planet surfaces!
  let nearestBody = bodyById.station;
  let minSurfaceDist = Infinity;
  for (const b of BODIES) {
    const sd = Math.max(2, ship.group.position.distanceTo(b.worldPos) - b.radius);
    if (sd < minSurfaceDist) {
      minSurfaceDist = sd;
      nearestBody = b;
    }
  }
  // Auto-update active sector info if flying close to another celestial body
  if (nearestBody !== orbit.body && minSurfaceDist < nearestBody.radius * 4 + 120) {
    orbit.body = nearestBody;
    updateInfo(nearestBody);
    updateNav();
  }

  const speedScale = clamp(minSurfaceDist * 0.85, 28, 8500) * (boost ? 3.2 : 1.0);

  // Smooth rotational rates (A/D yaw-bank + mouse drag pitch/yaw)
  flight.yawRate += (strafeYaw * 1.45 - flight.yawRate) * Math.min(1, dt * 6.0);
  flight.pitchRate *= Math.pow(0.04, dt);
  ship.group.rotateY(flight.yawRate * dt);
  ship.group.rotateX(flight.pitchRate * dt);

  // Level horizon gently when not pitching
  const euler = new THREE.Euler().setFromQuaternion(ship.group.quaternion, 'YXZ');
  euler.z *= Math.pow(0.15, dt);
  euler.x = clamp(euler.x, -1.35, 1.35);
  ship.group.quaternion.setFromEuler(euler);

  _shipFwd.set(0, 0, -1).applyQuaternion(ship.group.quaternion);
  _shipRight.set(1, 0, 0).applyQuaternion(ship.group.quaternion);
  _shipUp.set(0, 1, 0).applyQuaternion(ship.group.quaternion);

  if (warp.active && !warp.teleported && warp.jumped) {
    // Visual high-speed lunge during warp
    ship.update(dt, time, 1.0, true, 0, 0);
  } else {
    const accel = speedScale * 2.4;
    if (Math.abs(thrustFwd) > 0.01) {
      flight.vel.addScaledVector(_shipFwd, thrustFwd * accel * dt);
    }
    if (Math.abs(liftUp) > 0.01) {
      flight.vel.addScaledVector(_shipUp, liftUp * accel * 0.65 * dt);
    }
    // Space inertial damping
    flight.vel.multiplyScalar(Math.pow(0.22, dt));
    ship.group.position.addScaledVector(flight.vel, dt);

    // Prevent colliding inside solid planets
    for (const b of BODIES) {
      if (b.id === 'station') continue;
      const minR = b.radius * 1.04 + 6;
      const diff = _look.copy(ship.group.position).sub(b.worldPos);
      const len = diff.length();
      if (len < minR && len > 0.001) {
        ship.group.position.copy(b.worldPos).addScaledVector(diff.normalize(), minR);
        flight.vel.projectOnPlane(diff);
      }
    }

    const curThrottle = clamp(Math.max(0, thrustFwd) + flight.vel.length() / (speedScale + 1), 0.12, 1.0);
    ship.update(dt, time, curThrottle, boost && thrustFwd > 0, flight.pitchRate, -flight.yawRate);
  }

  // Spring-damped 3rd-Person Chase Camera behind & slightly above the Valkyrie starship
  const chaseBack = boost && thrustFwd > 0 ? 15.5 : 12.5;
  const desiredCam = _camOffset.copy(ship.group.position)
    .addScaledVector(_shipFwd, -chaseBack)
    .addScaledVector(_shipUp, 3.4);
  flight.camPos.lerp(desiredCam, Math.min(1, dt * 10.5));
  camera.position.copy(flight.camPos);

  const aimPoint = _look.copy(ship.group.position)
    .addScaledVector(_shipFwd, 45)
    .addScaledVector(_shipUp, 1.4);
  camera.lookAt(aimPoint);
  camera.rotateZ(-flight.yawRate * 0.08);

  // Telemetry in Flight mode
  const spdKmS = flight.vel.length() * KM_PER_UNIT;
  ui.speed.textContent = spdKmS > 1 ? Math.round(spdKmS).toLocaleString('en-US') + ' km/s' : '0 km/s 悬停';
  ui.dist.textContent = nearestBody.name + ' · ' + formatKm(minSurfaceDist * KM_PER_UNIT);
  ui.status.textContent = boost && thrustFwd > 0 ? '等离子加力巡航' : '第三人称自由穿梭';
}

/* ------------------------------------------------------------------ */
/* Main Loop                                                           */
/* ------------------------------------------------------------------ */
const clock = new THREE.Clock();
const _ndc = new V3();
let simTime = 0;
let markerAccumulator = 0;
let lastProjectionFov = camera.fov;

function frame(stepDt) {
  const dt = (typeof stepDt === 'number' && stepDt > 0) ? Math.min(stepDt, 0.033) : (FIXED_DT || Math.min(clock.getDelta(), 0.033));
  simTime += dt;
  const time = simTime;

  for (const fn of updatables) fn(dt, time);
  updateWarp(dt);

  if (mode === 'flight') {
    updateFlightMode(dt, time);
  } else {
    updateOrbitCamera(dt, time);
  }

  // Apply warp shake & dynamic FOV
  const sh = fx.shake;
  if (sh > 0.001) {
    camera.rotateX(sh * 0.0035 * (Math.sin(time * 41.0) + 0.6 * Math.sin(time * 23.7 + 1.3)));
    camera.rotateY(sh * 0.0035 * (Math.sin(time * 37.3 + 2.1) + 0.6 * Math.sin(time * 19.1)));
    camera.rotateZ(sh * 0.002 * Math.sin(time * 11.7));
  }
  camera.fov = fx.fov;
  if (Math.abs(camera.fov - lastProjectionFov) > 0.001) {
    camera.updateProjectionMatrix();
    lastProjectionFov = camera.fov;
  }

  // Keep directional sunLight centered near camera so lighting stays crisp across 300,000 units
  sunLight.position.copy(camera.position).addScaledVector(sunDir, 5000);
  sunLight.target.position.copy(camera.position);

  markerAccumulator += dt;
  if (markerAccumulator >= 0.066) {
    updateWorldMarkers();
    markerAccumulator = 0;
  }

  // Hyperspace streaks & plasma wormhole uniforms
  travel += fx.speed * dt;
  streaks.visible = fx.streakI > 0.002;
  streaks.material.uniforms.uTravel.value = travel;
  streaks.material.uniforms.uStretch.value = fx.stretch;
  streaks.material.uniforms.uIntensity.value = fx.streakI;

  tunnel.visible = fx.tunnelA > 0.002;
  tunnel.material.uniforms.uAlpha.value = fx.tunnelA;
  tunnel.material.uniforms.uTravel.value = travel;
  tunnel.material.uniforms.uTime.value = time;
  tunnel.rotation.z += dt * 0.26;

  scene.backgroundIntensity = fx.bg;
  deepStars.position.copy(camera.position);
  deepStars.material.uniforms.uTime.value = time;
  deepStars.material.uniforms.uAlpha.value = fx.bg / 0.5;
  bloom.strength = fx.bloom;

  // Earth night-city terminator view-space sun vector + optical Sun lens flare
  earthUniforms.sunDirView.value.copy(sunDir).transformDirection(camera.matrixWorldInverse);
  _ndc.copy(sunWorldPos).project(camera);
  let sunVis = 0;
  if (_ndc.z < 1 && fx.bg > 0.1) {
    const edge = 1 - smooth(0.82, 1.32, Math.max(Math.abs(_ndc.x), Math.abs(_ndc.y)));
    sunVis = edge * (fx.bg / 0.5) * 0.85;
  }
  const P = post.uniforms;
  P.uSun.value.set(_ndc.x * 0.5 + 0.5, _ndc.y * 0.5 + 0.5);
  P.uSunVis.value = sunVis;
  P.uTime.value = time;
  P.uCA.value = fx.ca;
  P.uBlur.value = fx.blur;
  P.uFlash.value = fx.flash;
  P.uShock.value = fx.shock;
  P.uShockAmp.value = fx.shockAmp;
  P.uGlow.value = fx.glow;
  P.uAnam.value = fx.anam;

  const dU = dust.material.uniforms;
  dU.uCam.value.copy(camera.position);
  dU.uOpacity.value = 0.55 * (1 - fx.streakI);

  composer.render();
  if (!MANUAL_STEP && !document.hidden) requestAnimationFrame(frame);
}

window.__step = (n = 1, dt = 0.25) => { for (let i = 0; i < n; i++) frame(dt); };

/* ------------------------------------------------------------------ */
/* Boot & Interactive Controls                                         */
/* ------------------------------------------------------------------ */
const loadBar = $('load-bar');
const startBtn = $('start');

manager.onProgress = (_u, loaded, total) => {
  loadBar.style.width = ((loaded / total) * 100).toFixed(0) + '%';
};
manager.onLoad = () => {
  const pmrem = new THREE.PMREMGenerator(renderer);
  envMap = pmrem.fromEquirectangular(T.stars).texture;
  pmrem.dispose();

  buildSolarSystem();
  buildArchitectUI();
  buildNav();
  buildWorldMarkers();
  arriveAtBody(bodyById.station, 1, 1);

  streaks.visible = tunnel.visible = true;
  // Upload textures in small batches so a tablet does not freeze on one long GPU upload task.
  const warmTextureBatch = (from = 0) => {
    const to = Math.min(from + 2, allTextures.length);
    for (let i = from; i < to; i++) renderer.initTexture(allTextures[i]);
    loadBar.style.width = (90 + (to / allTextures.length) * 10).toFixed(0) + '%';
    if (to < allTextures.length) {
      requestAnimationFrame(() => warmTextureBatch(to));
      return;
    }
    renderer.compile(scene, camera);
    streaks.visible = tunnel.visible = false;
    frame();
    startBtn.disabled = false;
    document.querySelector('.loader-sub').textContent = '宇宙级 3D 空间站 · 星际战舰 · 太阳系全天体就绪';
  };
  warmTextureBatch();
};

startBtn.addEventListener('click', () => {
  audio.init();
  started = true;
  document.body.classList.add('ready');
  // Dramatic opening: approach the distant Cosmic Station with glowing night-lit Earth filling the background!
  arriveAtBody(bodyById.station, 3.6, 6.5);
  audio.arrive();
});

// Mode Switcher buttons
document.querySelectorAll('.mode-btn').forEach((btn) => {
  btn.addEventListener('click', () => setMode(btn.dataset.mode));
});

$('reset-view').addEventListener('click', () => {
  if (mode === 'architect') {
    focusStationModule(null);
    station.setExplode(0);
    syncExplodeControls(0);
    orbit.targetYaw = 0.42;
    orbit.targetPitch = 0.2;
  } else if (mode === 'panorama') {
    arriveAtBody(orbit.body, 1, 1);
  } else {
    ship.group.lookAt(ship.group.position.clone().multiplyScalar(2).sub(orbit.body.worldPos));
    flight.vel.set(0, 0, 0);
  }
});

$('sound-toggle').addEventListener('click', (e) => {
  const on = !audio.enabled;
  audio.setEnabled(on);
  e.currentTarget.setAttribute('aria-pressed', String(on));
  e.currentTarget.querySelector('.label').textContent = on ? '音效 开' : '音效 关';
});

// Pointer Orbit / Flight Steering + 3D Raycast Picking on Cosmic Station Modules
canvas.addEventListener('pointerdown', (e) => {
  if (warp.active) return;
  pointer.down = true;
  pointer.moved = false;
  pointer.downX = pointer.lastX = e.clientX;
  pointer.downY = pointer.lastY = e.clientY;
  canvas.setPointerCapture(e.pointerId);
});

window.addEventListener('pointermove', (e) => {
  pointer.x = (e.clientX / window.innerWidth) * 2 - 1;
  pointer.y = (e.clientY / window.innerHeight) * 2 - 1;
  if (!pointer.down || warp.active) return;
  const dx = e.clientX - pointer.lastX;
  const dy = e.clientY - pointer.lastY;
  pointer.lastX = e.clientX;
  pointer.lastY = e.clientY;
  if (Math.hypot(e.clientX - pointer.downX, e.clientY - pointer.downY) > 5) pointer.moved = true;

  if (mode === 'flight') {
    flight.yawRate -= dx * 0.0085;
    flight.pitchRate -= dy * 0.0075;
  } else {
    orbit.targetYaw -= dx * 0.0045;
    orbit.targetPitch = clamp(orbit.targetPitch + dy * 0.0036, -1.35, 1.35);
  }
});

window.addEventListener('pointerup', (e) => {
  if (!pointer.down) return;
  pointer.down = false;
  // Click without dragging: raycast 3D Cosmic Station modules!
  if (!pointer.moved && !warp.active && mode !== 'flight') {
    ndcMouse.set((e.clientX / window.innerWidth) * 2 - 1, -(e.clientY / window.innerHeight) * 2 + 1);
    raycaster.setFromCamera(ndcMouse, camera);
    const hits = raycaster.intersectObjects(station.pickables, false);
    if (hits.length > 0) {
      const modId = hits[0].object.userData.moduleId;
      if (mode !== 'architect') setMode('architect');
      focusStationModule(station.getSelected() === modId ? null : modId);
    } else if (mode === 'architect') {
      focusStationModule(null);
    }
  }
});

window.addEventListener('pointercancel', () => { pointer.down = false; pointer.moved = true; });
window.addEventListener('blur', () => { pointer.down = false; for (const k of Object.keys(keys)) keys[k] = false; });

canvas.addEventListener('wheel', (e) => {
  e.preventDefault();
  if (warp.active || mode === 'flight') return;
  const minD = orbit.body.id === 'station' ? 16 : orbit.body.radius * 1.35;
  const maxD = orbit.body.id === 'station' ? 2800 : orbit.body.radius * 45;
  orbit.targetDist = clamp(orbit.targetDist * Math.exp(e.deltaY * 0.001), minD, maxD);
}, { passive: false });

window.addEventListener('keydown', (e) => {
  keys[e.code] = true;
  if (e.code === 'KeyR') $('reset-view').click();
  if (e.code === 'Digit1') setMode('panorama');
  if (e.code === 'Digit2') setMode('architect');
  if (e.code === 'Digit3') setMode('flight');
});
window.addEventListener('keyup', (e) => { keys[e.code] = false; });

document.addEventListener('visibilitychange', () => {
  if (!MANUAL_STEP && !document.hidden) {
    clock.start();
    requestAnimationFrame(frame);
  }
});

window.addEventListener('resize', () => {
  const w = window.innerWidth, h = window.innerHeight;
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
  renderer.setSize(w, h);
  composer.setSize(w, h);
  bloom.setSize(w * 0.78, h * 0.78);
  post.uniforms.uRes.value.set(w * PR, h * PR);
});
